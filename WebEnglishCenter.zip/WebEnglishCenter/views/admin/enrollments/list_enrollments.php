<?php
session_start();
include $_SERVER['DOCUMENT_ROOT'] . '/WebEnglishCenter/functions/db_connection.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../../login.php");
    exit();
}

$conn = getDbConnection();

// Phân quyền
$is_admin = isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
$is_student = isset($_SESSION['role']) && $_SESSION['role'] === 'student';
$is_teacher = isset($_SESSION['role']) && $_SESSION['role'] === 'teacher';

// Kiểm tra thông báo thành công
$success_message = '';
if (isset($_SESSION['enrollment_success'])) {
    $success_message = $_SESSION['enrollment_success'];
    unset($_SESSION['enrollment_success']);
}

// Cấu hình phân trang
$records_per_page = 8;
$page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int) $_GET['page'] : 1;
$offset = ($page - 1) * $records_per_page;

// Tìm kiếm
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$where_clause = '';
$search_param = '';

if (!empty($search)) {
    $where_clause = "WHERE c.course_name LIKE ? OR c.description LIKE ?";
    $search_param = "%$search%";
}

// Đếm tổng số bản ghi
$count_sql = "SELECT COUNT(*) as total FROM courses c $where_clause";
if (!empty($search)) {
    $count_stmt = $conn->prepare($count_sql);
    $count_stmt->bind_param("ss", $search_param, $search_param);
    $count_stmt->execute();
    $total_records = $count_stmt->get_result()->fetch_assoc()['total'];
    $count_stmt->close();
} else {
    $total_records = $conn->query($count_sql)->fetch_assoc()['total'];
}

$total_pages = ceil($total_records / $records_per_page);

// Lấy danh sách khóa học với thông tin số học viên đã đăng ký
$sql = "SELECT c.*, 
               (SELECT COUNT(*) FROM enrollments e WHERE e.course_id = c.id ) as enrolled_count
        FROM courses c 
        $where_clause
        ORDER BY c.created_at DESC
        LIMIT ? OFFSET ?";

if (!empty($search)) {
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssii", $search_param, $search_param, $records_per_page, $offset);
} else {
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $records_per_page, $offset);
}
$stmt->execute();
$result = $stmt->get_result();

// Nếu là student, lấy danh sách khóa học đã đăng ký
$enrolled_courses = [];
if ($is_student) {
    $enrolled_sql = "SELECT course_id FROM enrollments WHERE student_id = ? AND status IN ('active', 'pending')";
    $enrolled_stmt = $conn->prepare($enrolled_sql);
    $enrolled_stmt->bind_param("i", $_SESSION['user_id']);
    $enrolled_stmt->execute();
    $enrolled_result = $enrolled_stmt->get_result();
    while ($row = $enrolled_result->fetch_assoc()) {
        $enrolled_courses[] = $row['course_id'];
    }
    $enrolled_stmt->close();
}

// Lấy danh sách students để admin có thể thêm vào khóa học
$students = [];
if ($is_admin) {
    $students_sql = "SELECT id, full_name, email FROM students WHERE status = 'active' ORDER BY full_name";
    $students_result = $conn->query($students_sql);
    if ($students_result) {
        while ($student = $students_result->fetch_assoc()) {
            $students[] = $student;
        }
    }
}
?>
<!doctype html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Danh sách khóa học - English Center</title>

    <!--begin::Accessibility Meta Tags-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes" />
    <meta name="color-scheme" content="light dark" />
    <meta name="theme-color" content="#007bff" media="(prefers-color-scheme: light)" />
    <meta name="theme-color" content="#1a1a1a" media="(prefers-color-scheme: dark)" />
    <!--end::Accessibility Meta Tags-->

    <!--begin::Primary Meta Tags-->
    <meta name="title" content="Base English Center - Dashboard" />
    <meta name="author" content="Base English Center" />
    <meta name="description" content="Base English Center Admin Dashboard" />
    <meta name="keywords" content="english center, education, admin dashboard" />
    <!--end::Primary Meta Tags-->

    <!--begin::Accessibility Features-->
    <meta name="supported-color-schemes" content="light dark" />
    <base href="/WebEnglishCenter/">
    <link rel="preload" href="css/admincss/adminlte.css" as="style" />
    <!--end::Accessibility Features-->

    <!--begin::Fonts-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css"
        integrity="sha256-tXJfXfp6Ewt1ilPzLDtQnJV4hclT9XuaZUKyUvmyr+Q=" crossorigin="anonymous" media="print"
        onload="this.media='all'" />
    <!--end::Fonts-->

    <!--begin::Third Party Plugin(OverlayScrollbars)-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css"
        crossorigin="anonymous" />
    <!--end::Third Party Plugin(OverlayScrollbars)-->

    <!--begin::Third Party Plugin(Bootstrap Icons)-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css"
        crossorigin="anonymous" />
    <!--end::Third Party Plugin(Bootstrap Icons)-->

    <!--begin::Required Plugin(AdminLTE)-->
    <link rel="stylesheet" href="css/admincss/adminlte.css" />
    <!--end::Required Plugin(AdminLTE)-->

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />

    <style>
        /* Modal fallback styles */
        .modal.show {
            display: block !important;
            background-color: rgba(0, 0, 0, 0.5);
        }

        .modal-backdrop.fade.show {
            position: fixed;
            top: 0;
            left: 0;
            z-index: 1040;
            width: 100vw;
            height: 100vh;
            background-color: #000;
            opacity: 0.5;
        }

        /* Đảm bảo modal hiển thị trên cùng */
        .modal {
            z-index: 1050;
        }

        .role-badge {
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 0.8rem;
            margin-left: 8px;
        }

        .role-admin {
            background: #dc2626;
            color: white;
        }

        .role-student {
            background: #3b82f6;
            color: white;
        }

        .role-teacher {
            background: #ea580c;
            color: white;
        }

        .course-card {
            background: white;
            border-radius: 8px;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
            overflow: hidden;
            display: flex;
            flex-direction: column;
        }

        .course-photo img {
            width: 100%;
            height: 200px;
            object-fit: cover;
        }

        .course-info {
            padding: 20px;
            flex-grow: 1;
        }

        .course-title {
            margin: 0 0 10px 0;
            color: #2d3748;
            font-size: 1.25rem;
        }

        .course-description {
            color: #6b7280;
            margin-bottom: 15px;
        }

        .course-meta {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }

        .course-detail {
            display: flex;
            align-items: center;
            gap: 8px;
            color: #6b7280;
            font-size: 0.9rem;
        }

        .course-actions {
            padding: 15px 20px;
            background: #f8f9fa;
            border-top: 1px solid #e5e7eb;
            display: flex;
            gap: 10px;
        }

        .enrolled-badge {
            background: #10b981;
            color: white;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 0.8rem;
            display: inline-flex;
            align-items: center;
            gap: 4px;
            margin-bottom: 10px;
        }

        .no-courses {
            text-align: center;
            padding: 40px;
            color: #9ca3af;
        }

        .no-courses i {
            font-size: 3rem;
            margin-bottom: 10px;
        }

        .student-checkbox {
            display: flex;
            align-items: center;
            padding: 10px;
            border: 1px solid #e5e7eb;
            border-radius: 6px;
            margin-bottom: 8px;
        }

        .student-checkbox input {
            margin-right: 10px;
        }

        .student-info {
            flex-grow: 1;
        }

        .student-name {
            font-weight: 500;
        }

        .student-email {
            font-size: 0.875rem;
            color: #6b7280;
        }

        .modal {
            display: none;
            position: fixed;
            z-index: 1050;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0, 0, 0, 0.5);
        }

        .modal-content {
            background-color: #fff;
            margin: 5% auto;
            border-radius: 8px;
            width: 90%;
            max-width: 600px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .modal-header {
            padding: 20px;
            border-bottom: 1px solid #e5e7eb;
            display: flex;
            justify-content: between;
            align-items: center;
        }

        .modal-header h3 {
            margin: 0;
            flex-grow: 1;
        }

        .close-btn {
            background: none;
            border: none;
            font-size: 1.5rem;
            cursor: pointer;
            color: #6b7280;
        }

        .modal-body {
            padding: 20px;
            max-height: 60vh;
            overflow-y: auto;
        }

        .modal-footer {
            padding: 20px;
            border-top: 1px solid #e5e7eb;
            display: flex;
            justify-content: flex-end;
            gap: 10px;
        }

        .success-message {
            background: #d1fae5;
            color: #166534;
            padding: 12px 16px;
            border-radius: 6px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 8px;
            animation: fadeIn 0.3s ease-out;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes fadeOut {
            from {
                opacity: 1;
                transform: translateY(0);
            }

            to {
                opacity: 0;
                transform: translateY(-10px);
            }
        }

        .auto-hide {
            animation: fadeIn 0.3s ease-out;
        }
    </style>
</head>

<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
    <!--begin::App Wrapper-->
    <div class="app-wrapper">

        <!-- Include Menu -->
        <?php include __DIR__ . '/../menu.php'; ?>

        <!--begin::App Main-->
        <main class="app-main">
            <!--begin::App Content Header-->
            <div class="app-content-header">
                <!--begin::Container-->
                <div class="container-fluid">
                    <!--begin::Row-->
                    <div class="row">
                        <div class="col-sm-6">
                            <h3 class="mb-0">
                                <?php if ($is_admin): ?>
                                    Quản lý ghi danh
                                <?php else: ?>
                                    Danh sách khóa học
                                <?php endif; ?>
                            </h3>
                        </div>
                        <div class="col-sm-6">
                            <ol class="breadcrumb float-sm-end">
                                <li class="breadcrumb-item"><a href="/WebEnglishCenter/views/admin/index2.php">Home</a>
                                </li>
                                <li class="breadcrumb-item active" aria-current="page">
                                    <?php if ($is_admin): ?>
                                        Quản lý ghi danh
                                    <?php else: ?>
                                        Khóa học
                                    <?php endif; ?>
                                </li>
                            </ol>
                        </div>
                    </div>
                    <!--end::Row-->
                </div>
                <!--end::Container-->
            </div>

            <div class="app-content">
                <!--begin::Container-->
                <div class="container-fluid">
                    <!-- Success Message -->
                    <?php if (!empty($success_message)): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <i class="fas fa-check-circle me-2"></i>
                            <?= htmlspecialchars($success_message) ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>

                    <!-- Thống kê -->
                    <div class="row mb-3">
                        <div class="col-md-4">
                            <div class="info-box">
                                <span class="info-box-icon bg-primary">
                                    <i class="fas fa-list"></i>
                                </span>
                                <div class="info-box-content">
                                    <span class="info-box-text">Tổng số khóa học</span>
                                    <span class="info-box-number"><?= $total_records ?></span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="info-box">
                                <span class="info-box-icon bg-success">
                                    <i class="fas fa-file-alt"></i>
                                </span>
                                <div class="info-box-content">
                                    <span class="info-box-text">Trang hiện tại</span>
                                    <span class="info-box-number"><?= $page ?>/<?= $total_pages ?></span>
                                </div>
                            </div>
                        </div>
                        <?php if (!empty($search)): ?>
                            <div class="col-md-4">
                                <div class="info-box">
                                    <span class="info-box-icon bg-info">
                                        <i class="fas fa-search"></i>
                                    </span>
                                    <div class="info-box-content">
                                        <span class="info-box-text">Kết quả tìm kiếm</span>
                                        <span class="info-box-number">"<?= htmlspecialchars($search) ?>"</span>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>

                    <!-- Controls Section -->
                    <div class="row mb-3">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-header">
                                    <h5 class="card-title mb-0">
                                        <i class="fas fa-graduation-cap"></i>
                                        <?php if ($is_admin): ?>
                                            Quản lý ghi danh
                                        <?php else: ?>
                                            Danh sách khóa học
                                        <?php endif; ?>
                                        <?php if (!$is_admin): ?>
                                            <span class="role-badge role-<?= $_SESSION['role'] ?>">
                                                <?= ucfirst($_SESSION['role']) ?>
                                            </span>
                                        <?php endif; ?>
                                    </h5>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-8">
                                            <form method="GET" action="" class="search-form">
                                                <div class="input-group">
                                                    <input type="text" name="search"
                                                        value="<?= htmlspecialchars($search) ?>"
                                                        placeholder="Tìm kiếm khóa học..." class="form-control">
                                                    <button type="submit" class="btn btn-primary">
                                                        <i class="fas fa-search"></i>
                                                    </button>
                                                    <?php if (!empty($search)): ?>
                                                        <a href="?" class="btn btn-secondary">
                                                            <i class="fas fa-times"></i> Xóa lọc
                                                        </a>
                                                    <?php endif; ?>
                                                </div>
                                                <input type="hidden" name="page" value="1">
                                            </form>
                                        </div>
                                        <div class="col-md-4 text-end">
                                            <?php if ($is_admin): ?>
                                                <a href="/WebEnglishCenter/views/admin/enrollments/add_enrollments.php"
                                                    class="btn btn-success">
                                                    <i class="fas fa-plus"></i> Thêm khóa học
                                                </a>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="row mt-2">
                                        <div class="col-12">
                                            <small class="text-muted">
                                                <i class="fas fa-info-circle"></i>
                                                Hiển thị
                                                <?= min($offset + 1, $total_records) ?>-<?= min($offset + $records_per_page, $total_records) ?>
                                                trong tổng số <?= $total_records ?> khóa học
                                            </small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Course Cards -->
                    <div class="row">
                        <?php
                        if ($result && $result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                $photo = !empty($row['photo']) ? "uploads/courses/" . $row['photo'] : "https://via.placeholder.com/400x180/e5e7eb/9ca3af?text=No+Image";


                                $is_enrolled = in_array($row['id'], $enrolled_courses);

                                echo "<div class='col-md-6 col-lg-4 mb-4'>";
                                echo "<div class='course-card'>";

                                // Course photo
                                echo "<div class='course-photo'>";
                                echo "<img src='$photo' alt='Ảnh khóa học'>";
                                echo "</div>";

                                // Course info
                                echo "<div class='course-info'>";

                                // Enrolled badge for students
                                if ($is_student && $is_enrolled) {
                                    echo "<span class='enrolled-badge'><i class='fas fa-check-circle'></i> Đã đăng ký</span>";
                                }

                                echo "<h3 class='course-title'>" . htmlspecialchars($row['course_name']) . "</h3>";

                                if (!empty($row['description'])) {
                                    echo "<p class='course-description'>" . htmlspecialchars($row['description']) . "</p>";
                                }

                                echo "<div class='course-meta'>";

                                if (!empty($row['duration'])) {
                                    echo "<div class='course-detail'>";
                                    echo "<i class='fas fa-clock'></i>";
                                    echo "<span><strong>Thời lượng:</strong> " . htmlspecialchars($row['duration']) . "</span>";
                                    echo "</div>";
                                }

                                if (!empty($row['price'])) {
                                    echo "<div class='course-detail'>";
                                    echo "<i class='fas fa-tag'></i>";
                                    echo "<span><strong>Học phí:</strong> " . number_format($row['price'], 0, ',', '.') . " VNĐ</span>";
                                    echo "</div>";
                                }

                                echo "<div class='course-detail'>";
                                echo "<i class='fas fa-users'></i>";
                                echo "<span><strong>Đã đăng ký:</strong> " . $row['enrolled_count'] . " học viên</span>";
                                echo "</div>";

                                if (!empty($row['created_at'])) {
                                    echo "<div class='course-detail'>";
                                    echo "<i class='fas fa-calendar-plus'></i>";
                                    echo "<span><strong>Ngày tạo:</strong> " . date('d/m/Y', strtotime($row['created_at'])) . "</span>";
                                    echo "</div>";
                                }

                                echo "</div>"; // End course-meta
                                echo "</div>"; // End course-info
                        
                                // Actions
                                echo "<div class='course-actions'>";

                                if ($is_admin) {
                                    // Admin actions
                                    echo "<a href='/WebEnglishCenter/views/admin/enrollments/edit_enrollments.php?id=" . $row['id'] . "' class='btn btn-sm btn-primary'>";
                                    echo "<i class='fas fa-edit'></i> Sửa";
                                    echo "</a>";

                                    echo "<button onclick='openAddStudentsModal(" . $row['id'] . ", \"" . htmlspecialchars($row['course_name'], ENT_QUOTES) . "\")' class='btn btn-sm btn-info'>";
                                    echo "<i class='fas fa-user-plus'></i> Thêm SV";
                                    echo "</button>";

                                    echo "<a href='/WebEnglishCenter/handle/course_process.php?delete_id=" . $row['id'] . "' ";
                                    echo "class='btn btn-sm btn-danger' ";
                                    echo "onclick='return confirm(\"Bạn có chắc chắn muốn xóa khóa học này?\\nHành động này không thể hoàn tác!\")' ";
                                    echo "title='Xóa khóa học'>";
                                    echo "<i class='fas fa-trash'></i> Xóa";
                                    echo "</a>";

                                } elseif ($is_student) {
                                    // Student actions
                                    if (!$is_enrolled) {
                                        echo "<a href='/WebEnglishCenter/handle/enrollment_process.php?course_id=" . $row['id'] . "&student_id=" . $_SESSION['user_id'] . "' ";
                                        echo "class='btn btn-sm btn-primary' ";
                                        echo "onclick='return confirm(\"Bạn có chắc chắn muốn đăng ký khóa học này?\")' ";
                                        echo ">";
                                        echo "<i class='fas fa-user-plus'></i> Đăng ký";
                                        echo "</a>";
                                    } else {
                                        echo "<span class='btn btn-sm btn-success' style='background-color: #6c757d; color: white; cursor: default;'>";
                                        echo "<i class='fas fa-check'></i> Đã đăng ký";
                                        echo "</span>";
                                    }
                                }

                                echo "</div>"; // End course-actions
                                echo "</div>"; // End course-card
                                echo "</div>"; // End col
                            }
                        } else {
                            echo "<div class='col-12'>";
                            echo "<div class='no-courses'>";
                            echo "<i class='fas fa-graduation-cap'></i><br>";
                            echo (empty($search) ? "Chưa có khóa học nào trong hệ thống" : "Không tìm thấy khóa học nào phù hợp");
                            echo "</div>";
                            echo "</div>";
                        }
                        $stmt->close();
                        ?>
                    </div>

                    <!-- Pagination -->
                    <?php if ($total_pages > 1): ?>
                        <div class="row">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="d-flex justify-content-between align-items-center">
                                            <div class="text-muted">
                                                <i class="fas fa-info-circle"></i>
                                                Trang <?= $page ?> trong tổng số <?= $total_pages ?> trang
                                            </div>
                                            <nav>
                                                <ul class="pagination pagination-sm mb-0">
                                                    <!-- First page -->
                                                    <?php if ($page > 1): ?>
                                                        <li class="page-item">
                                                            <a class="page-link"
                                                                href="?page=1<?= !empty($search) ? '&search=' . urlencode($search) : '' ?>"
                                                                title="Trang đầu">
                                                                <i class="fas fa-angle-double-left"></i>
                                                            </a>
                                                        </li>
                                                    <?php else: ?>
                                                        <li class="page-item disabled">
                                                            <span class="page-link"><i
                                                                    class="fas fa-angle-double-left"></i></span>
                                                        </li>
                                                    <?php endif; ?>

                                                    <!-- Previous page -->
                                                    <?php if ($page > 1): ?>
                                                        <li class="page-item">
                                                            <a class="page-link"
                                                                href="?page=<?= $page - 1 ?><?= !empty($search) ? '&search=' . urlencode($search) : '' ?>"
                                                                title="Trang trước">
                                                                <i class="fas fa-angle-left"></i>
                                                            </a>
                                                        </li>
                                                    <?php else: ?>
                                                        <li class="page-item disabled">
                                                            <span class="page-link"><i class="fas fa-angle-left"></i></span>
                                                        </li>
                                                    <?php endif; ?>

                                                    <!-- Page numbers -->
                                                    <?php
                                                    $start_page = max(1, $page - 2);
                                                    $end_page = min($total_pages, $page + 2);

                                                    if ($start_page > 1) {
                                                        echo '<li class="page-item disabled"><span class="page-link">...</span></li>';
                                                    }

                                                    for ($i = $start_page; $i <= $end_page; $i++):
                                                        if ($i == $page): ?>
                                                            <li class="page-item active">
                                                                <span class="page-link"><?= $i ?></span>
                                                            </li>
                                                        <?php else: ?>
                                                            <li class="page-item">
                                                                <a class="page-link"
                                                                    href="?page=<?= $i ?><?= !empty($search) ? '&search=' . urlencode($search) : '' ?>"><?= $i ?></a>
                                                            </li>
                                                        <?php endif;
                                                    endfor;

                                                    if ($end_page < $total_pages) {
                                                        echo '<li class="page-item disabled"><span class="page-link">...</span></li>';
                                                    }
                                                    ?>

                                                    <!-- Next page -->
                                                    <?php if ($page < $total_pages): ?>
                                                        <li class="page-item">
                                                            <a class="page-link"
                                                                href="?page=<?= $page + 1 ?><?= !empty($search) ? '&search=' . urlencode($search) : '' ?>"
                                                                title="Trang sau">
                                                                <i class="fas fa-angle-right"></i>
                                                            </a>
                                                        </li>
                                                    <?php else: ?>
                                                        <li class="page-item disabled">
                                                            <span class="page-link"><i class="fas fa-angle-right"></i></span>
                                                        </li>
                                                    <?php endif; ?>

                                                    <!-- Last page -->
                                                    <?php if ($page < $total_pages): ?>
                                                        <li class="page-item">
                                                            <a class="page-link"
                                                                href="?page=<?= $total_pages ?><?= !empty($search) ? '&search=' . urlencode($search) : '' ?>"
                                                                title="Trang cuối">
                                                                <i class="fas fa-angle-double-right"></i>
                                                            </a>
                                                        </li>
                                                    <?php else: ?>
                                                        <li class="page-item disabled">
                                                            <span class="page-link"><i
                                                                    class="fas fa-angle-double-right"></i></span>
                                                        </li>
                                                    <?php endif; ?>
                                                </ul>
                                            </nav>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
                <!--end::Container-->
            </div>
            <!--end::App Content-->
        </main>
        <!--end::App Main-->

        <!--begin::Footer-->
        <footer class="app-footer">
            <div class="float-end d-none d-sm-inline">Base English Center</div>
            <strong>Copyright &copy; 2024 <a href="#" class="text-decoration-none">Base English Center</a>.</strong> All
            rights reserved.
        </footer>
        <!--end::Footer-->
    </div>
    <!--end::App Wrapper-->

    <!-- Modal thêm sinh viên (chỉ cho admin) -->
    <!-- Modal thêm sinh viên (chỉ cho admin) -->
    <?php if ($is_admin && !empty($students)): ?>
        <div id="addStudentsModal" class="modal fade" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title"><i class="fas fa-user-plus"></i> Thêm sinh viên vào khóa học</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <form id="addStudentsForm" action="/WebEnglishCenter/handle/enrollment_process.php" method="POST">
                        <input type="hidden" id="modal_course_id" name="course_id" value="">
                        <input type="hidden" name="action" value="bulk_add">

                        <div class="modal-body">
                            <p><strong>Khóa học:</strong> <span id="modal_course_name"></span></p>
                            <p style="margin-bottom: 20px; color: #6b7280;">Chọn sinh viên để thêm vào khóa học:</p>

                            <div style="margin-bottom: 15px;">
                                <label>
                                    <input type="checkbox" id="selectAll" onchange="toggleAllStudents(this)">
                                    <strong>Chọn tất cả</strong>
                                </label>
                            </div>

                            <?php foreach ($students as $student): ?>
                                <div class="student-checkbox">
                                    <input type="checkbox" name="student_ids[]" value="<?= $student['id'] ?>"
                                        class="student-checkbox-item">
                                    <div class="student-info">
                                        <div class="student-name"><?= htmlspecialchars($student['full_name']) ?></div>
                                        <div class="student-email"><?= htmlspecialchars($student['email']) ?></div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>

                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Hủy</button>
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-plus"></i> Thêm sinh viên
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <!--begin::Script-->
    <!--begin::Third Party Plugin(OverlayScrollbars)-->
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/browser/overlayscrollbars.browser.es6.min.js"
        crossorigin="anonymous"></script>
    <!--end::Third Party Plugin(OverlayScrollbars)-->

    <!--begin::Required Plugin(popperjs for Bootstrap 5)-->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
        crossorigin="anonymous"></script>
    <!--end::Required Plugin(popperjs for Bootstrap 5)-->

    <!--begin::Required Plugin(Bootstrap 5)-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.min.js"
        crossorigin="anonymous"></script>
    <!--end::Required Plugin(Bootstrap 5)-->

    <!--begin::Required Plugin(AdminLTE)-->
    <script src="js/adminlte.js"></script>
    <!--end::Required Plugin(AdminLTE)-->

    <script>
        // Modal functions với fallback hoàn chỉnh
        function openAddStudentsModal(courseId, courseName) {
            console.log('Opening modal for course:', courseId, courseName);

            // Set thông tin khóa học
            document.getElementById('modal_course_id').value = courseId;
            document.getElementById('modal_course_name').textContent = courseName;

            // Reset checkboxes
            const selectAll = document.getElementById('selectAll');
            if (selectAll) {
                selectAll.checked = false;
            }

            const checkboxes = document.querySelectorAll('.student-checkbox-item');
            checkboxes.forEach(cb => cb.checked = false);

            // Hiển thị modal - phương pháp đa dạng
            const modalElement = document.getElementById('addStudentsModal');
            if (!modalElement) {
                console.error('Modal element not found');
                return;
            }

            // Phương pháp 1: Thử Bootstrap trước
            if (typeof bootstrap !== 'undefined' && bootstrap.Modal) {
                console.log('Using Bootstrap Modal');
                const modal = new bootstrap.Modal(modalElement);
                modal.show();
            }
            // Phương pháp 2: Fallback - hiển thị thủ công
            else {
                console.log('Using manual modal display');
                modalElement.style.display = 'block';
                modalElement.style.background = 'rgba(0,0,0,0.5)';
                modalElement.classList.add('show');

                // Thêm backdrop
                let backdrop = document.createElement('div');
                backdrop.className = 'modal-backdrop fade show';
                document.body.appendChild(backdrop);

                // Lưu reference để remove sau
                modalElement._backdrop = backdrop;
            }
        }

        function toggleAllStudents(selectAllCheckbox) {
            const checkboxes = document.querySelectorAll('.student-checkbox-item');
            checkboxes.forEach(cb => cb.checked = selectAllCheckbox.checked);
        }

        // Hàm đóng modal fallback
        function closeModal() {
            const modalElement = document.getElementById('addStudentsModal');
            if (modalElement) {
                modalElement.style.display = 'none';
                modalElement.classList.remove('show');

                // Xóa backdrop nếu có
                if (modalElement._backdrop) {
                    document.body.removeChild(modalElement._backdrop);
                    modalElement._backdrop = null;
                }
            }
        }

        // Xử lý sự kiện khi DOM loaded
        document.addEventListener('DOMContentLoaded', function () {
            console.log('DOM loaded - initializing modal handlers');

            // Xử lý form submit
            const addStudentsForm = document.getElementById('addStudentsForm');
            if (addStudentsForm) {
                addStudentsForm.addEventListener('submit', function (e) {
                    const checkedBoxes = document.querySelectorAll('.student-checkbox-item:checked');
                    if (checkedBoxes.length === 0) {
                        e.preventDefault();
                        alert('Vui lòng chọn ít nhất một sinh viên!');
                        return false;
                    }
                    return confirm('Bạn có chắc chắn muốn thêm ' + checkedBoxes.length + ' sinh viên vào khóa học này?');
                });
            }

            // Xử lý nút đóng modal (fallback)
            document.querySelectorAll('[data-bs-dismiss="modal"], .btn-close').forEach(btn => {
                btn.addEventListener('click', closeModal);
            });

            // Đóng modal khi click outside (fallback)
            document.getElementById('addStudentsModal')?.addEventListener('click', function (e) {
                if (e.target === this) {
                    closeModal();
                }
            });
        });
    </script>
</body>

</html>