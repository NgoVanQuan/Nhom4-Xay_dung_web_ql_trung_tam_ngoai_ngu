<?php
session_start();
include $_SERVER['DOCUMENT_ROOT'] . '/WebEnglishCenter/functions/db_connection.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../../login.php");
    exit();
}

$conn = getDbConnection();

// Lấy ID giáo viên từ GET
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: list_teachers.php");
    exit();
}
$id = intval($_GET['id']);

// Lấy dữ liệu giáo viên theo ID
$stmt = $conn->prepare("SELECT id, full_name, dob, email, phone, specialization, photo, introduction FROM teachers WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$teacher = $result->fetch_assoc();

if (!$teacher) {
    header("Location: list_teachers.php");
    exit();
}

$conn->close();
?>

<!doctype html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Chi tiết giảng viên - English Center</title>

    <!--begin::Accessibility Meta Tags-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes" />
    <meta name="color-scheme" content="light dark" />
    <meta name="theme-color" content="#007bff" media="(prefers-color-scheme: light)" />
    <meta name="theme-color" content="#1a1a1a" media="(prefers-color-scheme: dark)" />
    <!--end::Accessibility Meta Tags-->

    <!--begin::Primary Meta Tags-->
    <meta name="title" content="Base English Center - Dashboard" />
    <meta name="author" content="Base English Center" />
    <meta name="description" content="Base English Center Admin Dashboard" />
    <meta name="keywords" content="english center, education, admin dashboard" />
    <!--end::Primary Meta Tags-->

    <!--begin::Accessibility Features-->
    <meta name="supported-color-schemes" content="light dark" />
    <base href="/WebEnglishCenter/">
    <link rel="preload" href="css/admincss/adminlte.css" as="style" />
    <!--end::Accessibility Features-->

    <!--begin::Fonts-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css"
        integrity="sha256-tXJfXfp6Ewt1ilPzLDtQnJV4hclT9XuaZUKyUvmyr+Q=" crossorigin="anonymous" media="print"
        onload="this.media='all'" />
    <!--end::Fonts-->

    <!--begin::Third Party Plugin(OverlayScrollbars)-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css"
        crossorigin="anonymous" />
    <!--end::Third Party Plugin(OverlayScrollbars)-->

    <!--begin::Third Party Plugin(Bootstrap Icons)-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css"
        crossorigin="anonymous" />
    <!--end::Third Party Plugin(Bootstrap Icons)-->

    <!--begin::Required Plugin(AdminLTE)-->
    <link rel="stylesheet" href="css/admincss/adminlte.css" />
    <!--end::Required Plugin(AdminLTE)-->

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />

    <style>
        .teacher-photo {
            width: 200px;
            height: 200px;
            object-fit: cover;
            border-radius: 8px;
            border: 3px solid #dee2e6;
        }

        .info-card {
            border-left: 4px solid #007bff;
        }

        .intro-card {
            background: #f8f9fa;
            border-radius: 8px;
        }
    </style>
</head>

<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
    <!--begin::App Wrapper-->
    <div class="app-wrapper">

        <!-- Include Menu -->
        <?php include __DIR__ . '/../menu.php'; ?>

        <!--begin::App Main-->
        <main class="app-main">
            <!--begin::App Content Header-->
            <div class="app-content-header">
                <!--begin::Container-->
                <div class="container-fluid">
                    <!--begin::Row-->
                    <div class="row">
                        <div class="col-sm-6">
                            <h3 class="mb-0">Chi tiết giảng viên</h3>
                        </div>
                        <div class="col-sm-6">
                            <ol class="breadcrumb float-sm-end">
                                <li class="breadcrumb-item"><a href="/WebEnglishCenter/views/admin/index2.php">Home</a>
                                </li>
                                <li class="breadcrumb-item"><a
                                        href="/WebEnglishCenter/views/admin/teachers/list_teachers.php">Giảng viên</a>
                                </li>
                                <li class="breadcrumb-item active" aria-current="page">Chi tiết giảng viên</li>
                            </ol>
                        </div>
                    </div>
                    <!--end::Row-->
                </div>
                <!--end::Container-->
            </div>

            <div class="app-content">
                <!--begin::Container-->
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-8 mx-auto">
                            <div class="card card-info">
                                <div class="card-header">
                                    <h3 class="card-title">
                                        <i class="fas fa-user-tie"></i>
                                        Thông tin giảng viên
                                    </h3>
                                    <div class="card-tools">
                                        <?php if ($_SESSION['role'] === 'admin'): ?>
                                            <a href="edit_teachers.php?id=<?= $teacher['id'] ?>"
                                                class="btn btn-primary btn-sm">
                                                <i class="fas fa-edit"></i> Chỉnh sửa
                                            </a>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-4 text-center">
                                            <?php
                                            $photoPath = !empty($teacher['photo']) ?
                                                "/WebEnglishCenter/uploads/teachers/" . $teacher['photo'] :
                                                "https://via.placeholder.com/200x200?text=No+Photo";
                                            ?>
                                            <img src="<?= $photoPath ?>" alt="Ảnh giảng viên"
                                                class="teacher-photo mb-3">
                                            <h4 class="text-primary"><?= htmlspecialchars($teacher['full_name']) ?></h4>
                                            <?php if (!empty($teacher['specialization'])): ?>
                                                <span
                                                    class="badge bg-success fs-6"><?= htmlspecialchars($teacher['specialization']) ?></span>
                                            <?php endif; ?>
                                        </div>

                                        <div class="col-md-8">
                                            <div class="card info-card mb-4">
                                                <div class="card-body">
                                                    <h6 class="card-title">
                                                        <i class="fas fa-info-circle text-primary"></i>
                                                        Thông tin cá nhân
                                                    </h6>
                                                    <div class="row mt-3">
                                                        <div class="col-md-6">
                                                            <p><strong><i class="fas fa-user"></i> Họ tên:</strong><br>
                                                                <?= htmlspecialchars($teacher['full_name']) ?></p>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <p><strong><i class="fas fa-birthday-cake"></i> Ngày
                                                                    sinh:</strong><br>
                                                                <?= date('d/m/Y', strtotime($teacher['dob'])) ?></p>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <p><strong><i class="fas fa-envelope"></i>
                                                                    Email:</strong><br>
                                                                <?= htmlspecialchars($teacher['email']) ?></p>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <p><strong><i class="fas fa-phone"></i> Số điện
                                                                    thoại:</strong><br>
                                                                <?= !empty($teacher['phone']) ? htmlspecialchars($teacher['phone']) : 'Chưa cập nhật' ?>
                                                            </p>
                                                        </div>
                                                    </div>
                                                    <?php if (!empty($teacher['specialization'])): ?>
                                                        <div class="row">
                                                            <div class="col-12">
                                                                <p><strong><i class="fas fa-graduation-cap"></i> Chuyên
                                                                        môn:</strong><br>
                                                                    <?= htmlspecialchars($teacher['specialization']) ?></p>
                                                            </div>
                                                        </div>
                                                    <?php endif; ?>
                                                </div>
                                            </div>

                                            <?php if (!empty($teacher['introduction'])): ?>
                                                <div class="card intro-card">
                                                    <div class="card-body">
                                                        <h6 class="card-title">
                                                            <i class="fas fa-file-alt text-primary"></i>
                                                            Giới thiệu
                                                        </h6>
                                                        <p class="card-text mt-3">
                                                            <?= nl2br(htmlspecialchars($teacher['introduction'])) ?>
                                                        </p>
                                                    </div>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="card-footer">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <small>
                                            <i class="fas fa-calendar"></i>
                                            Cập nhật lần cuối: <?= date('d/m/Y H:i') ?>
                                        </small>
                                        <div>
                                            <a href="views/admin/teachers/list_teachers.php"
                                                class="btn btn-secondary btn-sm">
                                                <i class="fas fa-arrow-left"></i> Quay lại
                                            </a>
                                            <?php if ($_SESSION['role'] === 'admin'): ?>
                                                <a href="views/admin/teachers/edit_teachers.php?id=<?= $teacher['id'] ?>"
                                                    class="btn btn-primary btn-sm ms-1">
                                                    <i class="fas fa-edit"></i> Chỉnh sửa
                                                </a>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--end::Container-->
            </div>
            <!--end::App Content-->
        </main>
        <!--end::App Main-->

        <!--begin::Footer-->
        <footer class="app-footer">
            <div class="float-end d-none d-sm-inline">Base English Center</div>
            <strong>Copyright &copy; 2024 <a href="#" class="text-decoration-none">Base English Center</a>.</strong> All
            rights reserved.
        </footer>
        <!--end::Footer-->
    </div>
    <!--end::App Wrapper-->

    <!--begin::Script-->
    <!--begin::Third Party Plugin(OverlayScrollbars)-->
    <script src="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/browser/overlayscrollbars.browser.es6.min.js"
        crossorigin="anonymous"></script>
    <!--end::Third Party Plugin(OverlayScrollbars)-->

    <!--begin::Required Plugin(popperjs for Bootstrap 5)-->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
        crossorigin="anonymous"></script>
    <!--end::Required Plugin(popperjs for Bootstrap 5)-->

    <!--begin::Required Plugin(Bootstrap 5)-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.min.js"
        crossorigin="anonymous"></script>
    <!--end::Required Plugin(Bootstrap 5)-->

    <!--begin::Required Plugin(AdminLTE)-->
    <script src="./js/adminlte.js"></script>
    <!--end::Required Plugin(AdminLTE)-->
</body>

</html>