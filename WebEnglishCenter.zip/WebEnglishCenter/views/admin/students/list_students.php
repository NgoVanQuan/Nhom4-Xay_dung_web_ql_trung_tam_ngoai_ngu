<?php
session_start();
include $_SERVER['DOCUMENT_ROOT'] . '/WebEnglishCenter/functions/db_connection.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../../login.php");
    exit();
}

$conn = getDbConnection();

// Cấu hình phân trang
$records_per_page = 10;
$page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int) $_GET['page'] : 1;
$offset = ($page - 1) * $records_per_page;

// Tìm kiếm
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$where_clause = '';
$search_param = '';

if (!empty($search)) {
    $where_clause = "WHERE full_name LIKE ? OR email LIKE ? OR phone LIKE ?";
    $search_param = "%$search%";
}

// Đếm tổng số bản ghi
$count_sql = "SELECT COUNT(*) as total FROM students $where_clause";
if (!empty($search)) {
    $count_stmt = $conn->prepare($count_sql);
    $count_stmt->bind_param("sss", $search_param, $search_param, $search_param);
    $count_stmt->execute();
    $total_records = $count_stmt->get_result()->fetch_assoc()['total'];
    $count_stmt->close();
} else {
    $total_records = $conn->query($count_sql)->fetch_assoc()['total'];
}

$total_pages = ceil($total_records / $records_per_page);

// Lấy danh sách học viên với phân trang
$sql = "SELECT id, full_name, dob, email, phone FROM students $where_clause ORDER BY id DESC LIMIT ? OFFSET ?";

if (!empty($search)) {
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssii", $search_param, $search_param, $search_param, $records_per_page, $offset);
} else {
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $records_per_page, $offset);
}

$stmt->execute();
$result = $stmt->get_result();

// Phân quyền
$is_admin = isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
$is_teacher = isset($_SESSION['role']) && $_SESSION['role'] === 'teacher';
$can_manage = $is_admin;
$can_view_details = $is_admin || $is_teacher;
?>

<!doctype html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Danh sách học viên - English Center</title>

    <!--begin::Accessibility Meta Tags-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes" />
    <meta name="color-scheme" content="light dark" />
    <meta name="theme-color" content="#007bff" media="(prefers-color-scheme: light)" />
    <meta name="theme-color" content="#1a1a1a" media="(prefers-color-scheme: dark)" />
    <!--end::Accessibility Meta Tags-->

    <!--begin::Primary Meta Tags-->
    <meta name="title" content="Base English Center - Dashboard" />
    <meta name="author" content="Base English Center" />
    <meta name="description" content="Base English Center Admin Dashboard" />
    <meta name="keywords" content="english center, education, admin dashboard" />
    <!--end::Primary Meta Tags-->

    <!--begin::Accessibility Features-->
    <meta name="supported-color-schemes" content="light dark" />
    <base href="/WebEnglishCenter/">
    <link rel="preload" href="css/admincss/adminlte.css" as="style" />
    <!--end::Accessibility Features-->

    <!--begin::Fonts-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css"
        integrity="sha256-tXJfXfp6Ewt1ilPzLDtQnJV4hclT9XuaZUKyUvmyr+Q=" crossorigin="anonymous" media="print"
        onload="this.media='all'" />
    <!--end::Fonts-->

    <!--begin::Third Party Plugin(OverlayScrollbars)-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css"
        crossorigin="anonymous" />
    <!--end::Third Party Plugin(OverlayScrollbars)-->

    <!--begin::Third Party Plugin(Bootstrap Icons)-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css"
        crossorigin="anonymous" />
    <!--end::Third Party Plugin(Bootstrap Icons)-->

    <!--begin::Required Plugin(AdminLTE)-->
    <link rel="stylesheet" href="css/admincss/adminlte.css" />
    <!--end::Required Plugin(AdminLTE)-->

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />

    <style>
        .course-list {
            display: none;
            margin-top: 8px;
            padding: 8px;
            background: #f8f9fa;
            border-radius: 4px;
            border-left: 3px solid #007bff;
        }

        .course-item {
            padding: 4px 0;
            font-size: 0.9rem;
        }

        .toggle-btn {
            background: #007bff;
            color: white;
            border: none;
            padding: 4px 8px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 0.8rem;
        }

        .toggle-btn:hover {
            background: #0056b3;
        }

        .role-badge {
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 0.8rem;
            margin-left: 8px;
        }

        .role-admin {
            background: #dc2626;
            color: white;
        }

        .role-teacher {
            background: #ea580c;
            color: white;
        }
    </style>
</head>

<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
    <!--begin::App Wrapper-->
    <div class="app-wrapper">

        <!-- Include Menu -->
        <?php include __DIR__ . '/../menu.php'; ?>

        <!--begin::App Main-->
        <main class="app-main">
            <!--begin::App Content Header-->
            <div class="app-content-header">
                <!--begin::Container-->
                <div class="container-fluid">
                    <!--begin::Row-->
                    <div class="row">
                        <div class="col-sm-6">
                            <h3 class="mb-0">Quản lý học viên</h3>
                        </div>
                        <div class="col-sm-6">
                            <ol class="breadcrumb float-sm-end">
                                <li class="breadcrumb-item"><a href="views/admin/index2.php">Home</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Học viên</li>
                            </ol>
                        </div>
                    </div>
                    <!--end::Row-->
                </div>
                <!--end::Container-->
            </div>

            <div class="app-content">
                <!--begin::Container-->
                <div class="container-fluid">
                    <!-- Thông báo và thống kê -->
                    <div class="row mb-3">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <h5>
                                                <i class="fas fa-user-graduate"></i>
                                                Quản lý học viên
                                                <?php if (!$can_manage): ?>
                                                    <span class="role-badge role-<?= $_SESSION['role'] ?>">
                                                        <?= ucfirst($_SESSION['role']) ?> - Chỉ xem
                                                    </span>
                                                <?php endif; ?>
                                            </h5>
                                        </div>
                                        <div class="col-md-6 text-end">
                                            <?php if ($can_manage): ?>
                                                <a href="views/admin/students/add_students.php" class="btn btn-primary">
                                                    <i class="fas fa-plus"></i> Thêm học viên
                                                </a>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="row mt-2">
                                        <div class="col-md-4">
                                            <small class="text-muted">
                                                <i class="fas fa-users"></i> Tổng số: <?= $total_records ?> học viên
                                            </small>
                                        </div>
                                        <div class="col-md-4">
                                            <small class="text-muted">
                                                <i class="fas fa-file-alt"></i> Trang <?= $page ?>/<?= $total_pages ?>
                                            </small>
                                        </div>
                                        <?php if (!empty($search)): ?>
                                            <div class="col-md-4">
                                                <small class="text-muted">
                                                    <i class="fas fa-search"></i> Kết quả cho:
                                                    "<?= htmlspecialchars($search) ?>"
                                                </small>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Tìm kiếm và bảng -->
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-header">
                                    <h5 class="card-title">Danh sách học viên</h5>
                                    <div class="card-tools">
                                        <form method="GET" action="" class="d-flex">
                                            <input type="text" name="search" value="<?= htmlspecialchars($search) ?>"
                                                placeholder="Tìm theo tên, email hoặc số điện thoại..."
                                                class="form-control me-2" style="width: 300px;">
                                            <button type="submit" class="btn btn-default">
                                                <i class="fas fa-search"></i>
                                            </button>
                                            <?php if (!empty($search)): ?>
                                                <a href="?" class="btn btn-default ms-2">
                                                    <i class="fas fa-times"></i> Xóa lọc
                                                </a>
                                            <?php endif; ?>
                                        </form>
                                    </div>
                                </div>
                                <!-- /.card-header -->
                                <div class="card-body p-0">
                                    <div class="table-responsive">
                                        <table class="table table-striped table-hover">
                                            <thead>
                                                <tr>
                                                    <th style="width: 60px;">STT</th>
                                                    <th>Họ tên</th>
                                                    <th style="width: 120px;">Ngày sinh</th>
                                                    <th>Email</th>
                                                    <th style="width: 120px;">SĐT</th>
                                                    <?php if ($can_view_details): ?>
                                                        <th style="width: 150px;">Khóa học</th>
                                                    <?php endif; ?>
                                                    <?php if ($can_manage): ?>
                                                        <th style="width: 160px;">Hành động</th>
                                                    <?php endif; ?>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                if ($result && $result->num_rows > 0) {
                                                    $stt = $offset + 1;
                                                    while ($row = $result->fetch_assoc()) {
                                                        echo "<tr>";
                                                        echo "<td><strong>" . $stt . "</strong></td>";
                                                        echo "<td><strong>" . htmlspecialchars($row['full_name']) . "</strong></td>";
                                                        echo "<td>" . date('d/m/Y', strtotime($row['dob'])) . "</td>";
                                                        echo "<td>" . htmlspecialchars($row['email']) . "</td>";
                                                        echo "<td>" . htmlspecialchars($row['phone']) . "</td>";

                                                        // Hiển thị khóa học (chỉ admin và teacher)
                                                        if ($can_view_details) {
                                                            echo "<td>";
                                                            // Lấy danh sách khóa học cho từng học viên
                                                            $sql_courses = "SELECT c.course_name 
                                                                    FROM enrollments e 
                                                                    JOIN courses c ON e.course_id = c.id 
                                                                    WHERE e.student_id = ?";
                                                            $stmt_courses = $conn->prepare($sql_courses);
                                                            $stmt_courses->bind_param("i", $row['id']);
                                                            $stmt_courses->execute();
                                                            $res_courses = $stmt_courses->get_result();
                                                            $courses = [];
                                                            while ($c = $res_courses->fetch_assoc()) {
                                                                $courses[] = $c['course_name'];
                                                            }
                                                            $stmt_courses->close();

                                                            if (!empty($courses)) {
                                                                echo "<button class='toggle-btn' onclick='toggleCourses(" . $row['id'] . ")'>
                                                                <i class='fas fa-eye'></i> Xem (" . count($courses) . ")
                                                              </button>
                                                              <div id='courses-" . $row['id'] . "' class='course-list'>";
                                                                foreach ($courses as $course) {
                                                                    echo "<div class='course-item'><i class='fas fa-book' style='color: #007bff;'></i> " . htmlspecialchars($course) . "</div>";
                                                                }
                                                                echo "</div>";
                                                            } else {
                                                                echo "<span style='color:#9ca3af; font-style: italic;'>
                                                                <i class='fas fa-minus-circle'></i> Chưa đăng ký
                                                              </span>";
                                                            }
                                                            echo "</td>";
                                                        }

                                                        // Hành động (chỉ admin)
                                                        if ($can_manage) {
                                                            echo "<td>";
                                                            echo "<a href='views/admin/students/edit_students.php?id=" . $row['id'] . "' class='btn btn-sm btn-primary' title='Sửa thông tin'>
                                                            <i class='fas fa-edit'></i>
                                                          </a>";
                                                            echo "<a href='handle/student_process.php?delete=" . $row['id'] . "' 
                                                             class='btn btn-sm btn-danger' 
                                                             title='Xóa học viên'
                                                             onclick='return confirm(\"Bạn có chắc chắn muốn xóa học viên này?\\nHành động này không thể hoàn tác!\")'>
                                                            <i class='fas fa-trash'></i>
                                                          </a>";
                                                            echo "</td>";
                                                        }

                                                        echo "</tr>";
                                                        $stt++;
                                                    }
                                                } else {
                                                    $colspan = 5;
                                                    if ($can_view_details)
                                                        $colspan++;
                                                    if ($can_manage)
                                                        $colspan++;

                                                    echo "<tr><td colspan='$colspan' class='text-center py-4'>
                                                    <i class='fas fa-user-slash fa-2x mb-2'></i><br>
                                                    " . (empty($search) ? "Chưa có học viên nào trong hệ thống" : "Không tìm thấy học viên nào phù hợp") . "
                                                  </td></tr>";
                                                }
                                                $stmt->close();
                                                $conn->close();
                                                ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    <!-- /.table-responsive -->
                                </div>
                                <!-- /.card-body -->
                                <?php if ($total_pages > 1): ?>
                                    <div class="card-footer clearfix">
                                        <div class="float-start">
                                            <small class="text-muted">
                                                Hiển thị
                                                <?= min($offset + 1, $total_records) ?>-<?= min($offset + $records_per_page, $total_records) ?>
                                                trong tổng số <?= $total_records ?>
                                            </small>
                                        </div>
                                        <ul class="pagination pagination-sm m-0 float-end">
                                            <!-- First page -->
                                            <?php if ($page > 1): ?>
                                                <li class="page-item"><a class="page-link"
                                                        href="?page=1<?= !empty($search) ? '&search=' . urlencode($search) : '' ?>"
                                                        title="Trang đầu">&laquo;</a></li>
                                            <?php else: ?>
                                                <li class="page-item disabled"><span class="page-link">&laquo;</span></li>
                                            <?php endif; ?>

                                            <!-- Previous page -->
                                            <?php if ($page > 1): ?>
                                                <li class="page-item"><a class="page-link"
                                                        href="?page=<?= $page - 1 ?><?= !empty($search) ? '&search=' . urlencode($search) : '' ?>"
                                                        title="Trang trước">&lsaquo;</a></li>
                                            <?php else: ?>
                                                <li class="page-item disabled"><span class="page-link">&lsaquo;</span></li>
                                            <?php endif; ?>

                                            <!-- Page numbers -->
                                            <?php
                                            $start_page = max(1, $page - 2);
                                            $end_page = min($total_pages, $page + 2);

                                            if ($start_page > 1) {
                                                echo '<li class="page-item disabled"><span class="page-link">...</span></li>';
                                            }

                                            for ($i = $start_page; $i <= $end_page; $i++):
                                                if ($i == $page): ?>
                                                    <li class="page-item active"><span class="page-link"><?= $i ?></span></li>
                                                <?php else: ?>
                                                    <li class="page-item"><a class="page-link"
                                                            href="?page=<?= $i ?><?= !empty($search) ? '&search=' . urlencode($search) : '' ?>"><?= $i ?></a>
                                                    </li>
                                                <?php endif;
                                            endfor;

                                            if ($end_page < $total_pages) {
                                                echo '<li class="page-item disabled"><span class="page-link">...</span></li>';
                                            }
                                            ?>

                                            <!-- Next page -->
                                            <?php if ($page < $total_pages): ?>
                                                <li class="page-item"><a class="page-link"
                                                        href="?page=<?= $page + 1 ?><?= !empty($search) ? '&search=' . urlencode($search) : '' ?>"
                                                        title="Trang sau">&rsaquo;</a></li>
                                            <?php else: ?>
                                                <li class="page-item disabled"><span class="page-link">&rsaquo;</span></li>
                                            <?php endif; ?>

                                            <!-- Last page -->
                                            <?php if ($page < $total_pages): ?>
                                                <li class="page-item"><a class="page-link"
                                                        href="?page=<?= $total_pages ?><?= !empty($search) ? '&search=' . urlencode($search) : '' ?>"
                                                        title="Trang cuối">&raquo;</a></li>
                                            <?php else: ?>
                                                <li class="page-item disabled"><span class="page-link">&raquo;</span></li>
                                            <?php endif; ?>
                                        </ul>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <!-- /.card -->
                        </div>
                    </div>
                </div>
                <!--end::Container-->
            </div>
            <!--end::App Content-->
        </main>
        <!--end::App Main-->

        <!--begin::Footer-->
        <footer class="app-footer">
            <div class="float-end d-none d-sm-inline">Base English Center</div>
            <strong>Copyright &copy; 2024 <a href="#" class="text-decoration-none">Base English Center</a>.</strong> All
            rights reserved.
        </footer>
        <!--end::Footer-->
    </div>
    <!--end::App Wrapper-->

    <!--begin::Script-->
    <!--begin::Third Party Plugin(OverlayScrollbars)-->
    <script src="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/browser/overlayscrollbars.browser.es6.min.js"
        crossorigin="anonymous"></script>
    <!--end::Third Party Plugin(OverlayScrollbars)-->

    <!--begin::Required Plugin(popperjs for Bootstrap 5)-->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
        crossorigin="anonymous"></script>
    <!--end::Required Plugin(popperjs for Bootstrap 5)-->

    <!--begin::Required Plugin(Bootstrap 5)-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.min.js"
        crossorigin="anonymous"></script>
    <!--end::Required Plugin(Bootstrap 5)-->

    <!--begin::Required Plugin(AdminLTE)-->
    <script src="./js/adminlte.js"></script>
    <!--end::Required Plugin(AdminLTE)-->

    <script>
        function toggleCourses(id) {
            const el = document.getElementById('courses-' + id);
            const btn = el.previousElementSibling;

            if (el.style.display === 'none' || el.style.display === '') {
                el.style.display = 'block';
                btn.innerHTML = '<i class="fas fa-eye-slash"></i> Ẩn';
            } else {
                el.style.display = 'none';
                btn.innerHTML = '<i class="fas fa-eye"></i> Xem (' + el.children.length + ')';
            }
        }

        // Ẩn tất cả danh sách khóa học khi trang được tải
        document.addEventListener('DOMContentLoaded', function () {
            const courseLists = document.querySelectorAll('.course-list');
            courseLists.forEach(list => {
                list.style.display = 'none';
            });
        });
    </script>
</body>

</html>