<?php
session_start();
include $_SERVER['DOCUMENT_ROOT'] . '/WebEnglishCenter/functions/db_connection.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../../login.php");
    exit();
}

$conn = getDbConnection();

// Lấy ID grade từ GET
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: list_grades.php");
    exit();
}
$id = intval($_GET['id']);

// Lấy dữ liệu grade theo ID
$stmt = $conn->prepare("SELECT * FROM grades WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$grade = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$grade) {
    echo "Không tìm thấy bản ghi!";
    exit();
}

// Lấy danh sách sinh viên, khóa học, giảng viên
$students = $conn->query("SELECT id, full_name FROM students ORDER BY full_name");
$courses = $conn->query("SELECT id, course_name FROM courses ORDER BY course_name");
$teachers = $conn->query("SELECT id, full_name FROM teachers ORDER BY full_name");

// Xử lý khi submit form
$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $student_id = intval($_POST['student_id']);
    $course_id = intval($_POST['course_id']);
    $teacher_id = isset($_POST['teacher_id']) && $_POST['teacher_id'] !== '' ? intval($_POST['teacher_id']) : NULL;
    $score = floatval($_POST['score']);
    $grade_letter = trim($_POST['grade_letter']);
    $notes = trim($_POST['notes']);

    if (empty($student_id))
        $errors[] = "Vui lòng chọn sinh viên";
    if (empty($course_id))
        $errors[] = "Vui lòng chọn khóa học";
    if ($score < 0 || $score > 100)
        $errors[] = "Điểm phải từ 0 đến 100";

    if (empty($errors)) {
        $stmt = $conn->prepare("UPDATE grades 
                                SET student_id = ?, course_id = ?, teacher_id = ?, score = ?, grade_letter = ?, notes = ?
                                WHERE id = ?");
        $stmt->bind_param("iiidssi", $student_id, $course_id, $teacher_id, $score, $grade_letter, $notes, $id);

        if ($stmt->execute()) {
            header("Location: list_grades.php?msg=updated");
            exit();
        } else {
            $errors[] = "Cập nhật thất bại: " . $stmt->error;
        }
        $stmt->close();
    }
}
?>
<!doctype html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Sửa điểm - English Center</title>

    <!--begin::Accessibility Meta Tags-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes" />
    <meta name="color-scheme" content="light dark" />
    <meta name="theme-color" content="#007bff" media="(prefers-color-scheme: light)" />
    <meta name="theme-color" content="#1a1a1a" media="(prefers-color-scheme: dark)" />
    <!--end::Accessibility Meta Tags-->

    <!--begin::Primary Meta Tags-->
    <meta name="title" content="Base English Center - Dashboard" />
    <meta name="author" content="Base English Center" />
    <meta name="description" content="Base English Center Admin Dashboard" />
    <meta name="keywords" content="english center, education, admin dashboard" />
    <!--end::Primary Meta Tags-->

    <!--begin::Accessibility Features-->
    <meta name="supported-color-schemes" content="light dark" />
    <base href="/WebEnglishCenter/">
    <link rel="preload" href="css/admincss/adminlte.css" as="style" />
    <!--end::Accessibility Features-->

    <!--begin::Fonts-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css"
        integrity="sha256-tXJfXfp6Ewt1ilPzLDtQnJV4hclT9XuaZUKyUvmyr+Q=" crossorigin="anonymous" media="print"
        onload="this.media='all'" />
    <!--end::Fonts-->

    <!--begin::Third Party Plugin(OverlayScrollbars)-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css"
        crossorigin="anonymous" />
    <!--end::Third Party Plugin(OverlayScrollbars)-->

    <!--begin::Third Party Plugin(Bootstrap Icons)-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css"
        crossorigin="anonymous" />
    <!--end::Third Party Plugin(Bootstrap Icons)-->

    <!--begin::Required Plugin(AdminLTE)-->
    <link rel="stylesheet" href="css/admincss/adminlte.css" />
    <!--end::Required Plugin(AdminLTE)-->

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
</head>

<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
    <!--begin::App Wrapper-->
    <div class="app-wrapper">

        <!-- Include Menu -->
        <?php include __DIR__ . '/../menu.php'; ?>

        <!--begin::App Main-->
        <main class="app-main">
            <!--begin::App Content Header-->
            <div class="app-content-header">
                <!--begin::Container-->
                <div class="container-fluid">
                    <!--begin::Row-->
                    <div class="row">
                        <div class="col-sm-6">
                            <h3 class="mb-0">Sửa điểm</h3>
                        </div>
                        <div class="col-sm-6">
                            <ol class="breadcrumb float-sm-end">
                                <li class="breadcrumb-item"><a href="/WebEnglishCenter/views/admin/index2.php">Home</a>
                                </li>
                                <li class="breadcrumb-item"><a
                                        href="/WebEnglishCenter/views/admin/grades/list_grades.php">Điểm số</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Sửa điểm</li>
                            </ol>
                        </div>
                    </div>
                    <!--end::Row-->
                </div>
                <!--end::Container-->
            </div>

            <div class="app-content">
                <!--begin::Container-->
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-8 mx-auto">
                            <div class="card card-primary">
                                <div class="card-header">
                                    <h3 class="card-title">Thông tin điểm</h3>
                                </div>
                                <form method="POST" action="">
                                    <div class="card-body">
                                        <?php if (!empty($errors)): ?>
                                            <div class="alert alert-danger">
                                                <?php echo implode('<br>', $errors); ?>
                                            </div>
                                        <?php endif; ?>
                                        <div class="form-group">
                                            <label for="student_id">Sinh viên</label>
                                            <select class="form-control" id="student_id" name="student_id" required>
                                                <option value="">-- Chọn sinh viên --</option>
                                                <?php
                                                $students->data_seek(0);
                                                while ($s = $students->fetch_assoc()) {
                                                    $sel = ($s['id'] == $grade['student_id']) ? 'selected' : '';
                                                    echo '<option value="' . $s['id'] . '" ' . $sel . '>' . htmlspecialchars($s['full_name']) . '</option>';
                                                }
                                                ?>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="course_id">Khóa học</label>
                                            <select class="form-control" id="course_id" name="course_id" required>
                                                <option value="">-- Chọn khóa học --</option>
                                                <?php
                                                $courses->data_seek(0);
                                                while ($c = $courses->fetch_assoc()) {
                                                    $sel = ($c['id'] == $grade['course_id']) ? 'selected' : '';
                                                    echo '<option value="' . $c['id'] . '" ' . $sel . '>' . htmlspecialchars($c['course_name']) . '</option>';
                                                }
                                                ?>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="teacher_id">Giảng viên</label>
                                            <select class="form-control" id="teacher_id" name="teacher_id">
                                                <option value="">-- Chưa chọn --</option>
                                                <?php
                                                $teachers->data_seek(0);
                                                while ($t = $teachers->fetch_assoc()) {
                                                    $sel = ($t['id'] == $grade['teacher_id']) ? 'selected' : '';
                                                    echo '<option value="' . $t['id'] . '" ' . $sel . '>' . htmlspecialchars($t['full_name']) . '</option>';
                                                }
                                                ?>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="score">Điểm số</label>
                                            <input type="number" class="form-control" id="score" name="score"
                                                step="0.01" min="0" max="100" required
                                                value="<?= htmlspecialchars($grade['score']) ?>">
                                        </div>
                                        <div class="form-group">
                                            <label for="grade_letter">Grade letter</label>
                                            <input type="text" class="form-control" id="grade_letter"
                                                name="grade_letter" maxlength="2"
                                                value="<?= htmlspecialchars($grade['grade_letter']) ?>">
                                        </div>
                                        <div class="form-group">
                                            <label for="notes">Ghi chú</label>
                                            <textarea class="form-control" id="notes" name="notes"
                                                rows="3"><?= htmlspecialchars($grade['notes']) ?></textarea>
                                        </div>
                                    </div>
                                    <div class="card-footer">
                                        <button type="submit" class="btn btn-primary">Cập nhật điểm</button>
                                        <a href="/WebEnglishCenter/views/admin/grades/list_grades.php"
                                            class="btn btn-default float-end">Quay lại</a>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <!--end::Container-->
            </div>
            <!--end::App Content-->
        </main>
        <!--end::App Main-->

        <!--begin::Footer-->
        <footer class="app-footer">
            <div class="float-end d-none d-sm-inline">Base English Center</div>
            <strong>Copyright &copy; 2024 <a href="#" class="text-decoration-none">Base English Center</a>.</strong> All
            rights reserved.
        </footer>
        <!--end::Footer-->
    </div>
    <!--end::App Wrapper-->

    <!--begin::Script-->
    <!--begin::Third Party Plugin(OverlayScrollbars)-->
    <script src="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/browser/overlayscrollbars.browser.es6.min.js"
        crossorigin="anonymous"></script>
    <!--end::Third Party Plugin(OverlayScrollbars)-->

    <!--begin::Required Plugin(popperjs for Bootstrap 5)-->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
        crossorigin="anonymous"></script>
    <!--end::Required Plugin(popperjs for Bootstrap 5)-->

    <!--begin::Required Plugin(Bootstrap 5)-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.min.js"
        crossorigin="anonymous"></script>
    <!--end::Required Plugin(Bootstrap 5)-->

    <!--begin::Required Plugin(AdminLTE)-->
    <script src="./js/adminlte.js"></script>
    <!--end::Required Plugin(AdminLTE)-->
</body>

</html>