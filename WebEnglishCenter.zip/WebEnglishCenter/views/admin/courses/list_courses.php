<?php
session_start();
include $_SERVER['DOCUMENT_ROOT'] . '/WebEnglishCenter/functions/db_connection.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../../login.php");
    exit();
}

$conn = getDbConnection();

// Cấu hình phân trang
$records_per_page = 6;
$page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int) $_GET['page'] : 1;
$offset = ($page - 1) * $records_per_page;

// Tìm kiếm
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$where_clause = '';
$search_param = '';

if (!empty($search)) {
    $where_clause = "WHERE c.course_name LIKE ? OR c.description LIKE ?";
    $search_param = "%$search%";
}

// Đếm tổng số bản ghi
$count_sql = "SELECT COUNT(*) as total FROM courses c $where_clause";
if (!empty($search)) {
    $count_stmt = $conn->prepare($count_sql);
    $count_stmt->bind_param("ss", $search_param, $search_param);
    $count_stmt->execute();
    $total_records = $count_stmt->get_result()->fetch_assoc()['total'];
    $count_stmt->close();
} else {
    $total_records = $conn->query($count_sql)->fetch_assoc()['total'];
}

$total_pages = ceil($total_records / $records_per_page);

// Lấy danh sách khóa học với phân trang
$sql = "SELECT c.id, c.course_name, c.description, c.fee, c.photo,
               t.full_name AS teacher_name,
               COUNT(e.student_id) AS total_students
        FROM courses c
        LEFT JOIN teachers t ON c.teacher_id = t.id
        LEFT JOIN enrollments e ON c.id = e.course_id
        $where_clause
        GROUP BY c.id, c.course_name, c.description, c.fee, c.photo, t.full_name
        ORDER BY c.id DESC 
        LIMIT ? OFFSET ?";

if (!empty($search)) {
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssii", $search_param, $search_param, $records_per_page, $offset);
} else {
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $records_per_page, $offset);
}
$stmt->execute();
$result = $stmt->get_result();

// Phân quyền
$is_admin = isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
$is_teacher = isset($_SESSION['role']) && $_SESSION['role'] === 'teacher';
$can_manage = $is_admin;
$can_view_details = $is_admin || $is_teacher;
?>
<!doctype html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Danh sách khóa học - English Center</title>

    <!--begin::Accessibility Meta Tags-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes" />
    <meta name="color-scheme" content="light dark" />
    <meta name="theme-color" content="#007bff" media="(prefers-color-scheme: light)" />
    <meta name="theme-color" content="#1a1a1a" media="(prefers-color-scheme: dark)" />
    <!--end::Accessibility Meta Tags-->

    <!--begin::Primary Meta Tags-->
    <meta name="title" content="Base English Center - Dashboard" />
    <meta name="author" content="Base English Center" />
    <meta name="description" content="Base English Center Admin Dashboard" />
    <meta name="keywords" content="english center, education, admin dashboard" />
    <!--end::Primary Meta Tags-->

    <!--begin::Accessibility Features-->
    <meta name="supported-color-schemes" content="light dark" />
    <base href="/WebEnglishCenter/">
    <link rel="preload" href="css/admincss/adminlte.css" as="style" />
    <!--end::Accessibility Features-->

    <!--begin::Fonts-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css"
        integrity="sha256-tXJfXfp6Ewt1ilPzLDtQnJV4hclT9XuaZUKyUvmyr+Q=" crossorigin="anonymous" media="print"
        onload="this.media='all'" />
    <!--end::Fonts-->

    <!--begin::Third Party Plugin(OverlayScrollbars)-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css"
        crossorigin="anonymous" />
    <!--end::Third Party Plugin(OverlayScrollbars)-->

    <!--begin::Third Party Plugin(Bootstrap Icons)-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css"
        crossorigin="anonymous" />
    <!--end::Third Party Plugin(Bootstrap Icons)-->

    <!--begin::Required Plugin(AdminLTE)-->
    <link rel="stylesheet" href="css/admincss/adminlte.css" />
    <!--end::Required Plugin(AdminLTE)-->

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />

    <style>
        .course-card {
            background: white;
            border-radius: 8px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            overflow: hidden;
            margin-bottom: 20px;
            transition: transform 0.2s;
        }

        .course-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        }

        .course-photo-wrapper {
            position: relative;
            height: 180px;
            overflow: hidden;
        }

        .course-photo {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .course-info {
            padding: 20px;
        }

        .course-name {
            font-size: 1.25rem;
            font-weight: 600;
            margin-bottom: 10px;
            color: #2d3748;
        }

        .course-meta {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
            font-size: 0.9rem;
            color: #6b7280;
        }

        .course-teacher, .course-students {
            display: flex;
            align-items: center;
            gap: 4px;
        }

        .course-desc {
            color: #6b7280;
            margin-bottom: 10px;
            font-size: 0.9rem;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
        }

        .course-fee {
            font-weight: 600;
            color: #059669;
            margin-bottom: 15px;
        }

        .card-actions {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .detail-link {
            background: #3b82f6;
            color: white;
            padding: 6px 12px;
            border-radius: 4px;
            text-decoration: none;
            font-size: 0.8rem;
            display: inline-flex;
            align-items: center;
            gap: 4px;
        }

        .card-admin-actions {
            display: flex;
            gap: 8px;
        }

        .btn-edit, .btn-delete {
            padding: 6px 10px;
            border-radius: 4px;
            text-decoration: none;
            font-size: 0.8rem;
            display: inline-flex;
            align-items: center;
            gap: 4px;
        }

        .btn-edit {
            background: #10b981;
            color: white;
        }

        .btn-delete {
            background: #ef4444;
            color: white;
        }

        .no-courses {
            text-align: center;
            padding: 40px;
            color: #9ca3af;
        }

        .no-courses i {
            font-size: 3rem;
            margin-bottom: 10px;
        }
    </style>
</head>

<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
    <!--begin::App Wrapper-->
    <div class="app-wrapper">

        <!-- Include Menu -->
        <?php include __DIR__ . '/../menu.php'; ?>

        <!--begin::App Main-->
        <main class="app-main">
            <!--begin::App Content Header-->
            <div class="app-content-header">
                <!--begin::Container-->
                <div class="container-fluid">
                    <!--begin::Row-->
                    <div class="row">
                        <div class="col-sm-6">
                            <h3 class="mb-0">Quản lý khóa học</h3>
                        </div>
                        <div class="col-sm-6">
                            <ol class="breadcrumb float-sm-end">
                                <li class="breadcrumb-item"><a href="/WebEnglishCenter/views/admin/index2.php">Home</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Khóa học</li>
                            </ol>
                        </div>
                    </div>
                    <!--end::Row-->
                </div>
                <!--end::Container-->
            </div>

            <div class="app-content">
                <!--begin::Container-->
                <div class="container-fluid">
                    <!-- Thống kê -->
                    <div class="row mb-3">
                        <div class="col-md-4">
                            <div class="info-box">
                                <span class="info-box-icon bg-primary">
                                    <i class="fas fa-book-open"></i>
                                </span>
                                <div class="info-box-content">
                                    <span class="info-box-text">Tổng số khóa học</span>
                                    <span class="info-box-number"><?= $total_records ?></span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="info-box">
                                <span class="info-box-icon bg-success">
                                    <i class="fas fa-file-alt"></i>
                                </span>
                                <div class="info-box-content">
                                    <span class="info-box-text">Trang hiện tại</span>
                                    <span class="info-box-number"><?= $page ?>/<?= $total_pages ?></span>
                                </div>
                            </div>
                        </div>
                        <?php if (!empty($search)): ?>
                            <div class="col-md-4">
                                <div class="info-box">
                                    <span class="info-box-icon bg-info">
                                        <i class="fas fa-search"></i>
                                    </span>
                                    <div class="info-box-content">
                                        <span class="info-box-text">Kết quả tìm kiếm</span>
                                        <span class="info-box-number">"<?= htmlspecialchars($search) ?>"</span>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>

                    <!-- Controls Section -->
                    <div class="row mb-3">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-header">
                                    <h5 class="card-title mb-0">
                                        <i class="fas fa-graduation-cap"></i>
                                        Danh sách khóa học
                                        <?php if (!$can_manage): ?>
                                                <span class="role-badge role-<?= $_SESSION['role'] ?>">
                                                    <?= ucfirst($_SESSION['role']) ?> - Chỉ xem
                                                </span>
                                        <?php endif; ?>
                                    </h5>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-8">
                                            <form method="GET" action="" class="search-form">
                                                <div class="input-group">
                                                    <input type="text" name="search" value="<?= htmlspecialchars($search) ?>"
                                                        placeholder="Tìm theo tên khóa học hoặc mô tả..." 
                                                        class="form-control">
                                                    <button type="submit" class="btn btn-primary">
                                                        <i class="fas fa-search"></i>
                                                    </button>
                                                    <?php if (!empty($search)): ?>
                                                            <a href="?" class="btn btn-secondary">
                                                                <i class="fas fa-times"></i> Xóa lọc
                                                            </a>
                                                    <?php endif; ?>
                                                </div>
                                                <input type="hidden" name="page" value="1">
                                            </form>
                                        </div>
                                        <div class="col-md-4 text-end">
                                            <?php if ($can_manage): ?>
                                                    <a href="/WebEnglishCenter/views/admin/courses/add_courses.php" class="btn btn-success">
                                                        <i class="fas fa-plus"></i> Thêm khóa học
                                                    </a>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="row mt-2">
                                        <div class="col-12">
                                            <small class="text-muted">
                                                <i class="fas fa-info-circle"></i>
                                                Hiển thị <?= min($offset + 1, $total_records) ?>-<?= min($offset + $records_per_page, $total_records) ?>
                                                trong tổng số <?= $total_records ?> khóa học
                                            </small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Course Cards -->
                    <div class="row">
                        <?php
                        if ($result && $result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                $photo = !empty($row['photo']) ? "uploads/courses/" . $row['photo'] : "https://via.placeholder.com/400x180/e5e7eb/9ca3af?text=No+Image";
                                $fee = number_format($row['fee'], 0, ',', '.') . ' VNĐ';
                                ?>
                                        <div class="col-md-6 col-lg-4 mb-4">
                                            <div class="course-card">
                                                <div class="course-photo-wrapper">
                                                    <img src="<?= $photo ?>" alt="Ảnh khóa học" class="course-photo">
                                                </div>
                                                <div class="course-info">
                                                    <div class="course-name"><?= htmlspecialchars($row['course_name']) ?></div>
                                                    <div class="course-meta">
                                                        <div class="course-teacher">
                                                            <i class="fas fa-chalkboard-teacher"></i>
                                                            <?= htmlspecialchars($row['teacher_name'] ?: 'Chưa phân công') ?>
                                                        </div>
                                                        <div class="course-students">
                                                            <i class="fas fa-user-graduate"></i>
                                                            <?= $row['total_students'] ?> học viên
                                                        </div>
                                                    </div>
                                                    <div class="course-desc"><?= htmlspecialchars($row['description']) ?></div>
                                                    <div class="course-fee"><?= $fee ?></div>
                                                    <div class="card-actions">
                                                        <a href="/WebEnglishCenter/views/admin/courses/course_detail.php?id=<?= $row['id'] ?>" class="detail-link" title="Xem chi tiết">
                                                            <i class="fas fa-eye"></i> Xem chi tiết
                                                        </a>
                                                        <?php if ($can_manage): ?>
                                                                <div class="card-admin-actions">
                                                                    <a href="/WebEnglishCenter/views/admin/courses/edit_courses.php?id=<?= $row['id'] ?>" class="btn-edit" title="Sửa khóa học">
                                                                        <i class="fas fa-edit"></i> Sửa
                                                                    </a>
                                                                    <a href="/WebEnglishCenter/handle/course_process.php?delete=<?= $row['id'] ?>" class="btn-delete" title="Xóa khóa học"
                                                                        onclick='return confirm("Bạn có chắc chắn muốn xóa khóa học này?\nHành động này không thể hoàn tác!")'>
                                                                        <i class="fas fa-trash"></i> Xóa
                                                                    </a>
                                                                </div>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <?php
                            }
                        } else {
                            ?>
                                <div class="col-12">
                                    <div class="no-courses">
                                        <i class="fas fa-book-open"></i>
                                        <h3><?= empty($search) ? "Chưa có khóa học nào" : "Không tìm thấy khóa học" ?></h3>
                                        <p><?= empty($search) ? "Hệ thống chưa có khóa học nào được thêm vào" : "Không tìm thấy khóa học phù hợp với từ khóa \"" . htmlspecialchars($search) . "\"" ?></p>
                                        <?php if ($can_manage && empty($search)): ?>
                                                <a href="/WebEnglishCenter/views/admin/courses/add_courses.php" class="btn btn-success mt-3">
                                                    <i class="fas fa-plus"></i> Thêm khóa học đầu tiên
                                                </a>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <?php
                        }
                        $stmt->close();
                        $conn->close();
                        ?>
                    </div>

                    <!-- Pagination -->
                    <?php if ($total_pages > 1): ?>
                        <div class="row">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="d-flex justify-content-between align-items-center">
                                            <div class="text-muted">
                                                <i class="fas fa-info-circle"></i>
                                                Trang <?= $page ?> trong tổng số <?= $total_pages ?> trang
                                            </div>
                                            <nav>
                                                <ul class="pagination pagination-sm mb-0">
                                                    <!-- First page -->
                                                    <?php if ($page > 1): ?>
                                                            <li class="page-item">
                                                                <a class="page-link" href="?page=1<?= !empty($search) ? '&search=' . urlencode($search) : '' ?>" title="Trang đầu">
                                                                    <i class="fas fa-angle-double-left"></i>
                                                                </a>
                                                            </li>
                                                    <?php else: ?>
                                                            <li class="page-item disabled">
                                                                <span class="page-link"><i class="fas fa-angle-double-left"></i></span>
                                                            </li>
                                                    <?php endif; ?>

                                                    <!-- Previous page -->
                                                    <?php if ($page > 1): ?>
                                                            <li class="page-item">
                                                                <a class="page-link" href="?page=<?= $page - 1 ?><?= !empty($search) ? '&search=' . urlencode($search) : '' ?>" title="Trang trước">
                                                                    <i class="fas fa-angle-left"></i>
                                                                </a>
                                                            </li>
                                                    <?php else: ?>
                                                            <li class="page-item disabled">
                                                                <span class="page-link"><i class="fas fa-angle-left"></i></span>
                                                            </li>
                                                    <?php endif; ?>

                                                    <!-- Page numbers -->
                                                    <?php
                                                    $start_page = max(1, $page - 2);
                                                    $end_page = min($total_pages, $page + 2);

                                                    if ($start_page > 1) {
                                                        echo '<li class="page-item disabled"><span class="page-link">...</span></li>';
                                                    }

                                                    for ($i = $start_page; $i <= $end_page; $i++):
                                                        if ($i == $page): ?>
                                                                    <li class="page-item active">
                                                                        <span class="page-link"><?= $i ?></span>
                                                                    </li>
                                                            <?php else: ?>
                                                                    <li class="page-item">
                                                                        <a class="page-link" href="?page=<?= $i ?><?= !empty($search) ? '&search=' . urlencode($search) : '' ?>"><?= $i ?></a>
                                                                    </li>
                                                            <?php endif;
                                                    endfor;

                                                    if ($end_page < $total_pages) {
                                                        echo '<li class="page-item disabled"><span class="page-link">...</span></li>';
                                                    }
                                                    ?>

                                                    <!-- Next page -->
                                                    <?php if ($page < $total_pages): ?>
                                                            <li class="page-item">
                                                                <a class="page-link" href="?page=<?= $page + 1 ?><?= !empty($search) ? '&search=' . urlencode($search) : '' ?>" title="Trang sau">
                                                                    <i class="fas fa-angle-right"></i>
                                                                </a>
                                                            </li>
                                                    <?php else: ?>
                                                            <li class="page-item disabled">
                                                                <span class="page-link"><i class="fas fa-angle-right"></i></span>
                                                            </li>
                                                    <?php endif; ?>

                                                    <!-- Last page -->
                                                    <?php if ($page < $total_pages): ?>
                                                            <li class="page-item">
                                                                <a class="page-link" href="?page=<?= $total_pages ?><?= !empty($search) ? '&search=' . urlencode($search) : '' ?>" title="Trang cuối">
                                                                    <i class="fas fa-angle-double-right"></i>
                                                                </a>
                                                            </li>
                                                    <?php else: ?>
                                                            <li class="page-item disabled">
                                                                <span class="page-link"><i class="fas fa-angle-double-right"></i></span>
                                                            </li>
                                                    <?php endif; ?>
                                                </ul>
                                            </nav>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
                <!--end::Container-->
            </div>
            <!--end::App Content-->
        </main>
        <!--end::App Main-->

        <!--begin::Footer-->
        <footer class="app-footer">
            <div class="float-end d-none d-sm-inline">Base English Center</div>
            <strong>Copyright &copy; 2024 <a href="#" class="text-decoration-none">Base English Center</a>.</strong> All
            rights reserved.
        </footer>
        <!--end::Footer-->
    </div>
    <!--end::App Wrapper-->

    <!--begin::Script-->
    <!--begin::Third Party Plugin(OverlayScrollbars)-->
    <script src="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/browser/overlayscrollbars.browser.es6.min.js"
        crossorigin="anonymous"></script>
    <!--end::Third Party Plugin(OverlayScrollbars)-->

    <!--begin::Required Plugin(popperjs for Bootstrap 5)-->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
        crossorigin="anonymous"></script>
    <!--end::Required Plugin(popperjs for Bootstrap 5)-->
    
    <!--begin::Required Plugin(Bootstrap 5)-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.min.js"
        crossorigin="anonymous"></script>
    <!--end::Required Plugin(Bootstrap 5)-->

    <!--begin::Required Plugin(AdminLTE)-->
    <script src="./js/adminlte.js"></script>
    <!--end::Required Plugin(AdminLTE)-->
</body>
</html>