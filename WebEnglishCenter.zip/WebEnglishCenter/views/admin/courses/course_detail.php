<?php
session_start();
include $_SERVER['DOCUMENT_ROOT'] . '/WebEnglishCenter/functions/db_connection.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../../login.php");
    exit();
}

$conn = getDbConnection();

// Lấy id khóa học từ URL
if (!isset($_GET['id'])) {
    header("Location: list_courses.php");
    exit();
}
$course_id = intval($_GET['id']);

// Lấy thông tin khóa học + giảng viên + số sinh viên
$sql = "SELECT c.id, c.course_name, c.description, c.fee, c.photo,
               t.full_name AS teacher_name, t.id AS teacher_id,
               COUNT(e.student_id) AS total_students
        FROM courses c
        LEFT JOIN teachers t ON c.teacher_id = t.id
        LEFT JOIN enrollments e ON c.id = e.course_id
        WHERE c.id = ?
        GROUP BY c.id, c.course_name, c.description, c.fee, c.photo, t.full_name, t.id";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $course_id);
$stmt->execute();
$result = $stmt->get_result();
$course = $result->fetch_assoc();
$stmt->close();

if (!$course) {
    header("Location: list_courses.php");
    exit();
}

$conn->close();
?>
<!doctype html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Chi tiết khóa học - <?= htmlspecialchars($course['course_name']) ?> - English Center</title>

    <!--begin::Accessibility Meta Tags-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes" />
    <meta name="color-scheme" content="light dark" />
    <meta name="theme-color" content="#007bff" media="(prefers-color-scheme: light)" />
    <meta name="theme-color" content="#1a1a1a" media="(prefers-color-scheme: dark)" />
    <!--end::Accessibility Meta Tags-->

    <!--begin::Primary Meta Tags-->
    <meta name="title" content="Base English Center - Dashboard" />
    <meta name="author" content="Base English Center" />
    <meta name="description" content="Base English Center Admin Dashboard" />
    <meta name="keywords" content="english center, education, admin dashboard" />
    <!--end::Primary Meta Tags-->

    <!--begin::Accessibility Features-->
    <meta name="supported-color-schemes" content="light dark" />
    <base href="/WebEnglishCenter/">
    <link rel="preload" href="css/admincss/adminlte.css" as="style" />
    <!--end::Accessibility Features-->

    <!--begin::Fonts-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css"
        integrity="sha256-tXJfXfp6Ewt1ilPzLDtQnJV4hclT9XuaZUKyUvmyr+Q=" crossorigin="anonymous" media="print"
        onload="this.media='all'" />
    <!--end::Fonts-->

    <!--begin::Third Party Plugin(OverlayScrollbars)-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css"
        crossorigin="anonymous" />
    <!--end::Third Party Plugin(OverlayScrollbars)-->

    <!--begin::Third Party Plugin(Bootstrap Icons)-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css"
        crossorigin="anonymous" />
    <!--end::Third Party Plugin(Bootstrap Icons)-->

    <!--begin::Required Plugin(AdminLTE)-->
    <link rel="stylesheet" href="css/admincss/adminlte.css" />
    <!--end::Required Plugin(AdminLTE)-->

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />

    <style>
        .course-photo {
            width: 100%;
            max-width: 400px;
            height: 250px;
            object-fit: cover;
            border-radius: 8px;
            border: 3px solid #dee2e6;
        }
        
        .info-card {
            border-left: 4px solid #007bff;
        }
        
        .intro-card {
            background: #f8f9fa;
            border-radius: 8px;
        }
        
        .detail-item {
            margin-bottom: 15px;
            padding-bottom: 15px;
            border-bottom: 1px solid #eee;
        }
        
        .detail-item:last-child {
            border-bottom: none;
            margin-bottom: 0;
            padding-bottom: 0;
        }
        
        .teacher-link {
            color: #007bff;
            text-decoration: none;
        }
        
        .teacher-link:hover {
            text-decoration: underline;
        }
        
        .fee-badge {
            background: linear-gradient(135deg, #10b981, #059669);
            color: white;
            padding: 8px 16px;
            border-radius: 20px;
            font-size: 1.2rem;
            font-weight: 600;
        }
    </style>
</head>

<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
    <!--begin::App Wrapper-->
    <div class="app-wrapper">

        <!-- Include Menu -->
        <?php include __DIR__ . '/../menu.php'; ?>

        <!--begin::App Main-->
        <main class="app-main">
            <!--begin::App Content Header-->
            <div class="app-content-header">
                <!--begin::Container-->
                <div class="container-fluid">
                    <!--begin::Row-->
                    <div class="row">
                        <div class="col-sm-6">
                            <h3 class="mb-0">Chi tiết khóa học</h3>
                        </div>
                        <div class="col-sm-6">
                            <ol class="breadcrumb float-sm-end">
                                <li class="breadcrumb-item"><a href="/WebEnglishCenter/views/admin/index2.php">Home</a>
                                </li>
                                <li class="breadcrumb-item"><a
                                        href="/WebEnglishCenter/views/admin/courses/list_courses.php">Khóa học</a>
                                </li>
                                <li class="breadcrumb-item active" aria-current="page">Chi tiết khóa học</li>
                            </ol>
                        </div>
                    </div>
                    <!--end::Row-->
                </div>
                <!--end::Container-->
            </div>

            <div class="app-content">
                <!--begin::Container-->
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-8 mx-auto">
                            <div class="card card-info">
                                <div class="card-header">
                                    <h3 class="card-title">
                                        <i class="fas fa-book-open"></i>
                                        Thông tin khóa học
                                    </h3>
                                    <div class="card-tools">
                                        <?php if ($_SESSION['role'] === 'admin'): ?>
                                                <a href="edit_courses.php?id=<?= $course['id'] ?>" class="btn btn-primary btn-sm">
                                                    <i class="fas fa-edit"></i> Chỉnh sửa
                                                </a>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-5 text-center mb-4">
                                            <?php
                                            $photoPath = !empty($course['photo']) ?
                                                "/WebEnglishCenter/uploads/courses/" . $course['photo'] :
                                                "https://via.placeholder.com/400x250?text=No+Image";
                                            ?>
                                            <img src="<?= $photoPath ?>" alt="Ảnh khóa học" class="course-photo mb-3">
                                            <h3 class="text-primary"><?= htmlspecialchars($course['course_name']) ?></h3>
                                            <div class="fee-badge mt-2">
                                                <?= number_format($course['fee'], 0, ',', '.') ?> VNĐ
                                            </div>
                                        </div>
                                        
                                        <div class="col-md-7">
                                            <div class="card info-card mb-4">
                                                <div class="card-body">
                                                    <h5 class="card-title mb-4">
                                                        <i class="fas fa-info-circle text-primary"></i>
                                                        Thông tin chi tiết
                                                    </h5>
                                                    
                                                    <div class="detail-item">
                                                        <div class="row">
                                                            <div class="col-sm-4">
                                                                <strong><i class="fas fa-book text-primary"></i> Tên khóa học:</strong>
                                                            </div>
                                                            <div class="col-sm-8">
                                                                <?= htmlspecialchars($course['course_name']) ?>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="detail-item">
                                                        <div class="row">
                                                            <div class="col-sm-4">
                                                                <strong><i class="fas fa-money-bill-wave text-primary"></i> Học phí:</strong>
                                                            </div>
                                                            <div class="col-sm-8">
                                                                <span class="text-success fw-bold">
                                                                    <?= number_format($course['fee'], 0, ',', '.') ?> VNĐ
                                                                </span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="detail-item">
                                                        <div class="row">
                                                            <div class="col-sm-4">
                                                                <strong><i class="fas fa-chalkboard-teacher text-primary"></i> Giảng viên:</strong>
                                                            </div>
                                                            <div class="col-sm-8">
                                                                <?php if ($course['teacher_name']): ?>
                                                                        <?php if ($course['teacher_id']): ?>
                                                                                <a href="/WebEnglishCenter/views/admin/teachers/teacher_detail.php?id=<?= $course['teacher_id'] ?>" 
                                                                                   class="teacher-link">
                                                                                    <?= htmlspecialchars($course['teacher_name']) ?>
                                                                                </a>
                                                                        <?php else: ?>
                                                                                <?= htmlspecialchars($course['teacher_name']) ?>
                                                                        <?php endif; ?>
                                                                <?php else: ?>
                                                                        <span class="text-muted">Chưa được gán</span>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="detail-item">
                                                        <div class="row">
                                                            <div class="col-sm-4">
                                                                <strong><i class="fas fa-users text-primary"></i> Học viên đã đăng ký:</strong>
                                                            </div>
                                                            <div class="col-sm-8">
                                                                <span class="fw-bold"><?= intval($course['total_students']) ?> học viên</span>
                                                                <?php if ($course['total_students'] > 0): ?>
                                                                        <span class="badge bg-primary ms-2"><?= $course['total_students'] ?></span>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <?php if (!empty($course['description'])): ?>
                                                    <div class="card intro-card">
                                                        <div class="card-body">
                                                            <h5 class="card-title mb-3">
                                                                <i class="fas fa-file-alt text-primary"></i>
                                                                Mô tả khóa học
                                                            </h5>
                                                            <div class="intro-content">
                                                                <?= nl2br(htmlspecialchars($course['description'])) ?>
                                                            </div>
                                                        </div>
                                                    </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="card-footer">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <small class="text-muted">
                                            <i class="fas fa-id-card"></i>
                                            Mã khóa học: #<?= $course['id'] ?>
                                        </small>
                                        <div>
                                            <a href="list_courses.php" class="btn btn-secondary">
                                                <i class="fas fa-arrow-left"></i> Quay lại
                                            </a>
                                            <a href="students_in_course.php?course_id=<?= $course['id'] ?>" class="btn btn-success ms-2">
                                                <i class="fas fa-users"></i> Xem học viên
                                            </a>
                                            <?php if ($_SESSION['role'] === 'admin'): ?>
                                                    <a href="edit_courses.php?id=<?= $course['id'] ?>" class="btn btn-primary ms-2">
                                                        <i class="fas fa-edit"></i> Chỉnh sửa
                                                    </a>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--end::Container-->
            </div>
            <!--end::App Content-->
        </main>
        <!--end::App Main-->

        <!--begin::Footer-->
        <footer class="app-footer">
            <div class="float-end d-none d-sm-inline">Base English Center</div>
            <strong>Copyright &copy; 2024 <a href="#" class="text-decoration-none">Base English Center</a>.</strong> All
            rights reserved.
        </footer>
        <!--end::Footer-->
    </div>
    <!--end::App Wrapper-->

    <!--begin::Script-->
    <!--begin::Third Party Plugin(OverlayScrollbars)-->
    <script src="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/browser/overlayscrollbars.browser.es6.min.js"
        crossorigin="anonymous"></script>
    <!--end::Third Party Plugin(OverlayScrollbars)-->

    <!--begin::Required Plugin(popperjs for Bootstrap 5)-->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
        crossorigin="anonymous"></script>
    <!--end::Required Plugin(popperjs for Bootstrap 5)-->

    <!--begin::Required Plugin(Bootstrap 5)-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.min.js"
        crossorigin="anonymous"></script>
    <!--end::Required Plugin(Bootstrap 5)-->

    <!--begin::Required Plugin(AdminLTE)-->
    <script src="./js/adminlte.js"></script>
    <!--end::Required Plugin(AdminLTE)-->
</body>
</html>