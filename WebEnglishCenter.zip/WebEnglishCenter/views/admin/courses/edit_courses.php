<?php
session_start();
include $_SERVER['DOCUMENT_ROOT'] . '/WebEnglishCenter/functions/db_connection.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../../login.php");
    exit();
}

// Kiểm tra quyền admin
if ($_SESSION['role'] !== 'admin') {
    header("Location: ../../unauthorized.php");
    exit();
}

$conn = getDbConnection();

// Lấy ID khóa học
$id = $_GET['id'] ?? null;
if (!$id) {
    header("Location: list_courses.php");
    exit();
}

// Lấy thông tin khóa học
$sql = "SELECT id, course_name, description, fee, teacher_id, photo FROM courses WHERE id=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$course = $result->fetch_assoc();
$stmt->close();

if (!$course) {
    echo "Khóa học không tồn tại!";
    exit();
}

// Lấy danh sách giáo viên
$teachers = $conn->query("SELECT id, full_name FROM teachers");

// Xử lý submit
$success = "";
$error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $course_name = trim($_POST['course_name']);
    $description = trim($_POST['description']);
    $fee = floatval($_POST['fee']);
    $teacher_id = !empty($_POST['teacher_id']) ? intval($_POST['teacher_id']) : null;

    // Validate dữ liệu
    if (empty($course_name) || $fee < 0) {
        $error = "Tên khóa học không được để trống và học phí không được âm!";
    } else {
        $photoName = $course['photo']; // giữ ảnh cũ

        // Kiểm tra nếu có upload ảnh mới
        if (isset($_FILES['photo']) && $_FILES['photo']['error'] === UPLOAD_ERR_OK) {
            $allowed_types = ['jpg', 'jpeg', 'png', 'gif'];
            $file_extension = strtolower(pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION));

            if (in_array($file_extension, $allowed_types)) {
                $newName = "course_" . $id . "_" . time() . "." . $file_extension;
                $uploadDir = $_SERVER['DOCUMENT_ROOT'] . "/WebEnglishCenter/uploads/courses/";

                // Tạo thư mục nếu chưa tồn tại
                if (!is_dir($uploadDir)) {
                    mkdir($uploadDir, 0777, true);
                }

                $uploadPath = $uploadDir . $newName;

                if (move_uploaded_file($_FILES['photo']['tmp_name'], $uploadPath)) {
                    $photoName = $newName;

                    // Xóa ảnh cũ nếu có
                    if (!empty($course['photo']) && file_exists($uploadDir . $course['photo'])) {
                        unlink($uploadDir . $course['photo']);
                    }
                } else {
                    $error = "Lỗi khi upload ảnh!";
                }
            } else {
                $error = "Chỉ chấp nhận file ảnh JPG, PNG, GIF!";
            }
        }

        if (empty($error)) {
            $stmt = $conn->prepare("UPDATE courses SET course_name=?, description=?, fee=?, teacher_id=?, photo=? WHERE id=?");
            $stmt->bind_param("ssdisi", $course_name, $description, $fee, $teacher_id, $photoName, $id);

            if ($stmt->execute()) {
                $success = "Cập nhật khóa học thành công!";
                // Cập nhật lại dữ liệu
                $course = array_merge($course, [
                    'course_name' => $course_name,
                    'description' => $description,
                    'fee' => $fee,
                    'teacher_id' => $teacher_id,
                    'photo' => $photoName
                ]);
            } else {
                $error = "Cập nhật thất bại: " . $stmt->error;
            }
        }
    }
}
?>
<!doctype html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Sửa khóa học - English Center</title>

    <!--begin::Accessibility Meta Tags-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes" />
    <meta name="color-scheme" content="light dark" />
    <meta name="theme-color" content="#007bff" media="(prefers-color-scheme: light)" />
    <meta name="theme-color" content="#1a1a1a" media="(prefers-color-scheme: dark)" />
    <!--end::Accessibility Meta Tags-->

    <!--begin::Primary Meta Tags-->
    <meta name="title" content="Base English Center - Dashboard" />
    <meta name="author" content="Base English Center" />
    <meta name="description" content="Base English Center Admin Dashboard" />
    <meta name="keywords" content="english center, education, admin dashboard" />
    <!--end::Primary Meta Tags-->

    <!--begin::Accessibility Features-->
    <meta name="supported-color-schemes" content="light dark" />
    <base href="/WebEnglishCenter/">
    <link rel="preload" href="css/admincss/adminlte.css" as="style" />
    <!--end::Accessibility Features-->

    <!--begin::Fonts-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css"
        integrity="sha256-tXJfXfp6Ewt1ilPzLDtQnJV4hclT9XuaZUKyUvmyr+Q=" crossorigin="anonymous" media="print"
        onload="this.media='all'" />
    <!--end::Fonts-->

    <!--begin::Third Party Plugin(OverlayScrollbars)-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css"
        crossorigin="anonymous" />
    <!--end::Third Party Plugin(OverlayScrollbars)-->

    <!--begin::Third Party Plugin(Bootstrap Icons)-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css"
        crossorigin="anonymous" />
    <!--end::Third Party Plugin(Bootstrap Icons)-->

    <!--begin::Required Plugin(AdminLTE)-->
    <link rel="stylesheet" href="css/admincss/adminlte.css" />
    <!--end::Required Plugin(AdminLTE)-->

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />

    <style>
        .course-photo-preview {
            width: 150px;
            height: 100px;
            object-fit: cover;
            border-radius: 8px;
            border: 2px solid #dee2e6;
        }

        .photo-section {
            text-align: center;
            padding: 20px;
            background: #f8f9fa;
            border-radius: 8px;
            margin-bottom: 20px;
        }

        .alert {
            margin-bottom: 20px;
        }
    </style>
</head>

<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
    <!--begin::App Wrapper-->
    <div class="app-wrapper">

        <!-- Include Menu -->
        <?php include __DIR__ . '/../menu.php'; ?>

        <!--begin::App Main-->
        <main class="app-main">
            <!--begin::App Content Header-->
            <div class="app-content-header">
                <!--begin::Container-->
                <div class="container-fluid">
                    <!--begin::Row-->
                    <div class="row">
                        <div class="col-sm-6">
                            <h3 class="mb-0">Sửa khóa học</h3>
                        </div>
                        <div class="col-sm-6">
                            <ol class="breadcrumb float-sm-end">
                                <li class="breadcrumb-item"><a href="/WebEnglishCenter/views/admin/index2.php">Home</a>
                                </li>
                                <li class="breadcrumb-item"><a
                                        href="/WebEnglishCenter/views/admin/courses/list_courses.php">Khóa học</a>
                                </li>
                                <li class="breadcrumb-item active" aria-current="page">Sửa khóa học</li>
                            </ol>
                        </div>
                    </div>
                    <!--end::Row-->
                </div>
                <!--end::Container-->
            </div>

            <div class="app-content">
                <!--begin::Container-->
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-8 mx-auto">
                            <?php if ($success): ?>
                                <div class="alert alert-success alert-dismissible fade show" role="alert">
                                    <i class="fas fa-check-circle"></i> <?= $success ?>
                                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                                </div>
                            <?php endif; ?>

                            <?php if ($error): ?>
                                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                    <i class="fas fa-exclamation-circle"></i> <?= $error ?>
                                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                                </div>
                            <?php endif; ?>

                            <div class="card card-primary">
                                <div class="card-header">
                                    <h3 class="card-title">
                                        <i class="fas fa-edit"></i>
                                        Thông tin khóa học
                                    </h3>
                                </div>
                                <form method="POST" enctype="multipart/form-data">
                                    <div class="card-body">
                                        <!-- Photo Section -->
                                        <div class="photo-section">
                                            <?php
                                            $photoPath = !empty($course['photo']) ?
                                                "/WebEnglishCenter/uploads/courses/" . $course['photo'] :
                                                "https://via.placeholder.com/150x100?text=No+Photo";
                                            ?>
                                            <img src="<?= $photoPath ?>" alt="Ảnh khóa học"
                                                class="course-photo-preview mb-3" id="photoPreview">
                                            <div class="mb-3">
                                                <label for="photo" class="form-label">Đổi ảnh khóa học</label>
                                                <input type="file" class="form-control" name="photo" id="photo"
                                                    accept="image/*">
                                                <div class="form-text">
                                                    Chấp nhận: JPG, PNG, GIF. Tối đa 2MB.
                                                </div>
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <label for="course_name">Tên khóa học <span
                                                    class="text-danger">*</span></label>
                                            <input type="text" class="form-control" id="course_name" name="course_name"
                                                value="<?= htmlspecialchars($course['course_name']) ?>" required>
                                        </div>

                                        <div class="form-group">
                                            <label for="description">Mô tả khóa học</label>
                                            <textarea class="form-control" id="description" name="description" rows="4"
                                                placeholder="Mô tả về khóa học..."><?= htmlspecialchars($course['description']) ?></textarea>
                                        </div>

                                        <div class="form-group">
                                            <label for="fee">Học phí (VNĐ) <span class="text-danger">*</span></label>
                                            <input type="number" class="form-control" id="fee" name="fee" step="1000"
                                                min="0" value="<?= $course['fee'] ?>" required>
                                        </div>

                                        <div class="form-group">
                                            <label for="teacher_id">Giảng viên phụ trách</label>
                                            <select class="form-control" id="teacher_id" name="teacher_id">
                                                <option value="">-- Chọn giảng viên --</option>
                                                <?php while ($t = $teachers->fetch_assoc()): ?>
                                                    <option value="<?= $t['id'] ?>" <?= $t['id'] == $course['teacher_id'] ? 'selected' : '' ?>>
                                                        <?= htmlspecialchars($t['full_name']) ?>
                                                    </option>
                                                <?php endwhile; ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="card-footer">
                                        <button type="submit" class="btn btn-primary">
                                            <i class="fas fa-save"></i> Cập nhật
                                        </button>
                                        <a href="/WebEnglishCenter/views/admin/courses/list_courses.php"
                                            class="btn btn-default float-end">
                                            <i class="fas fa-arrow-left"></i> Quay lại
                                        </a>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <!--end::Container-->
            </div>
            <!--end::App Content-->
        </main>
        <!--end::App Main-->

        <!--begin::Footer-->
        <footer class="app-footer">
            <div class="float-end d-none d-sm-inline">Base English Center</div>
            <strong>Copyright &copy; 2024 <a href="#" class="text-decoration-none">Base English Center</a>.</strong> All
            rights reserved.
        </footer>
        <!--end::Footer-->
    </div>
    <!--end::App Wrapper-->

    <!--begin::Script-->
    <!--begin::Third Party Plugin(OverlayScrollbars)-->
    <script src="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/browser/overlayscrollbars.browser.es6.min.js"
        crossorigin="anonymous"></script>
    <!--end::Third Party Plugin(OverlayScrollbars)-->

    <!--begin::Required Plugin(popperjs for Bootstrap 5)-->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
        crossorigin="anonymous"></script>
    <!--end::Required Plugin(popperjs for Bootstrap 5)-->

    <!--begin::Required Plugin(Bootstrap 5)-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.min.js"
        crossorigin="anonymous"></script>
    <!--end::Required Plugin(Bootstrap 5)-->

    <!--begin::Required Plugin(AdminLTE)-->
    <script src="./js/adminlte.js"></script>
    <!--end::Required Plugin(AdminLTE)-->

    <script>
        // Xem trước ảnh
        document.getElementById('photo').addEventListener('change', function (e) {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function (e) {
                    document.getElementById('photoPreview').src = e.target.result;
                }
                reader.readAsDataURL(file);
            }
        });

        // Format số tiền
        document.getElementById('fee').addEventListener('input', function (e) {
            let value = e.target.value.replace(/\D/g, '');
            e.target.value = value;
        });
    </script>
</body>

</html>