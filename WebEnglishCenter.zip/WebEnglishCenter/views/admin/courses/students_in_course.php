<?php
session_start();
include $_SERVER['DOCUMENT_ROOT'] . '/WebEnglishCenter/functions/db_connection.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../../login.php");
    exit();
}

$conn = getDbConnection();

$course_id = null;
$course_name = "";
$schedule_id = null;

// Trường hợp gọi từ khóa học
if (isset($_GET['course_id'])) {
    $course_id = intval($_GET['course_id']);
}
// Trường hợp gọi từ lịch học
elseif (isset($_GET['type']) && $_GET['type'] === 'schedule' && isset($_GET['id'])) {
    $schedule_id = intval($_GET['id']);
    // Lấy course_id từ schedule
    $stmt = $conn->prepare("SELECT course_id FROM schedules WHERE id = ?");
    $stmt->bind_param("i", $schedule_id);
    $stmt->execute();
    $stmt->bind_result($course_id);
    if (!$stmt->fetch()) {
        die("Không tìm thấy lịch học");
    }
    $stmt->close();
} else {
    die("Thiếu tham số");
}

// Lấy tên khóa học
$sql_course = "SELECT course_name FROM courses WHERE id = ?";
$stmt = $conn->prepare($sql_course);
$stmt->bind_param("i", $course_id);
$stmt->execute();
$stmt->bind_result($course_name);
$stmt->fetch();
$stmt->close();

// Lấy danh sách sinh viên
$sql_students = "SELECT s.id, s.full_name, s.email, s.phone, s.dob
                 FROM enrollments e
                 JOIN students s ON e.student_id = s.id
                 WHERE e.course_id = ?
                 ORDER BY s.full_name";
$stmt2 = $conn->prepare($sql_students);
$stmt2->bind_param("i", $course_id);
$stmt2->execute();
$result_students = $stmt2->get_result();

$total_students = $result_students->num_rows;
?>
<!doctype html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Học viên trong khóa học - English Center</title>

    <!--begin::Accessibility Meta Tags-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes" />
    <meta name="color-scheme" content="light dark" />
    <meta name="theme-color" content="#007bff" media="(prefers-color-scheme: light)" />
    <meta name="theme-color" content="#1a1a1a" media="(prefers-color-scheme: dark)" />
    <!--end::Accessibility Meta Tags-->

    <!--begin::Primary Meta Tags-->
    <meta name="title" content="Base English Center - Dashboard" />
    <meta name="author" content="Base English Center" />
    <meta name="description" content="Base English Center Admin Dashboard" />
    <meta name="keywords" content="english center, education, admin dashboard" />
    <!--end::Primary Meta Tags-->

    <!--begin::Accessibility Features-->
    <meta name="supported-color-schemes" content="light dark" />
    <base href="/WebEnglishCenter/">
    <link rel="preload" href="css/admincss/adminlte.css" as="style" />
    <!--end::Accessibility Features-->

    <!--begin::Fonts-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css"
        integrity="sha256-tXJfXfp6Ewt1ilPzLDtQnJV4hclT9XuaZUKyUvmyr+Q=" crossorigin="anonymous" media="print"
        onload="this.media='all'" />
    <!--end::Fonts-->

    <!--begin::Third Party Plugin(OverlayScrollbars)-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css"
        crossorigin="anonymous" />
    <!--end::Third Party Plugin(OverlayScrollbars)-->

    <!--begin::Third Party Plugin(Bootstrap Icons)-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css"
        crossorigin="anonymous" />
    <!--end::Third Party Plugin(Bootstrap Icons)-->

    <!--begin::Required Plugin(AdminLTE)-->
    <link rel="stylesheet" href="css/admincss/adminlte.css" />
    <!--end::Required Plugin(AdminLTE)-->

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
</head>

<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
    <!--begin::App Wrapper-->
    <div class="app-wrapper">

        <!-- Include Menu -->
        <?php include __DIR__ . '/../menu.php'; ?>

        <!--begin::App Main-->
        <main class="app-main">
            <!--begin::App Content Header-->
            <div class="app-content-header">
                <!--begin::Container-->
                <div class="container-fluid">
                    <!--begin::Row-->
                    <div class="row">
                        <div class="col-sm-6">
                            <h3 class="mb-0">Danh sách học viên</h3>
                        </div>
                        <div class="col-sm-6">
                            <ol class="breadcrumb float-sm-end">
                                <li class="breadcrumb-item"><a href="/WebEnglishCenter/views/admin/index2.php">Home</a>
                                </li>
                                <li class="breadcrumb-item"><a
                                        href="/WebEnglishCenter/views/admin/courses/list_courses.php">Khóa học</a>
                                </li>
                                <li class="breadcrumb-item active" aria-current="page">Học viên</li>
                            </ol>
                        </div>
                    </div>
                    <!--end::Row-->
                </div>
                <!--end::Container-->
            </div>

            <div class="app-content">
                <!--begin::Container-->
                <div class="container-fluid">
                    <!-- Thống kê -->
                    <div class="row mb-3">
                        <div class="col-md-4">
                            <div class="info-box">
                                <span class="info-box-icon bg-primary">
                                    <i class="fas fa-users"></i>
                                </span>
                                <div class="info-box-content">
                                    <span class="info-box-text">Tổng số học viên</span>
                                    <span class="info-box-number"><?= $total_students ?></span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-8">
                            <div class="info-box">
                                <span class="info-box-icon bg-info">
                                    <i class="fas fa-book"></i>
                                </span>
                                <div class="info-box-content">
                                    <span class="info-box-text">Khóa học</span>
                                    <span class="info-box-number"><?= htmlspecialchars($course_name) ?></span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-header">
                                    <h5 class="card-title mb-0">
                                        <i class="fas fa-user-graduate"></i>
                                        Danh sách học viên đăng ký
                                    </h5>
                                </div>
                                <div class="card-body">
                                    <?php if ($total_students > 0): ?>
                                        <div class="table-responsive">
                                            <table class="table table-bordered table-striped">
                                                <thead>
                                                    <tr>
                                                        <th>ID</th>
                                                        <th>Họ tên</th>
                                                        <th>Email</th>
                                                        <th>Số điện thoại</th>
                                                        <th>Ngày sinh</th>
                                                        <th>Thao tác</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php while ($row = $result_students->fetch_assoc()): ?>
                                                        <tr>
                                                            <td><?= $row['id'] ?></td>
                                                            <td>
                                                                <strong><?= htmlspecialchars($row['full_name']) ?></strong>
                                                            </td>
                                                            <td><?= htmlspecialchars($row['email']) ?></td>
                                                            <td><?= htmlspecialchars($row['phone']) ?></td>
                                                            <td><?= date('d/m/Y', strtotime($row['dob'])) ?></td>
                                                            <td>
                                                                <a href="/WebEnglishCenter/views/admin/students/student_detail.php?id=<?= $row['id'] ?>"
                                                                    class="btn btn-info btn-sm" title="Xem chi tiết">
                                                                    <i class="fas fa-eye"></i>
                                                                </a>
                                                            </td>
                                                        </tr>
                                                    <?php endwhile; ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    <?php else: ?>
                                        <div class="text-center py-4">
                                            <i class="fas fa-users fa-3x text-muted mb-3"></i>
                                            <h4 class="text-muted">Chưa có học viên nào đăng ký</h4>
                                            <p class="text-muted">Khóa học này hiện chưa có học viên đăng ký tham gia.</p>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div class="card-footer">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <div class="text-muted">
                                            <i class="fas fa-info-circle"></i>
                                            Tổng cộng: <?= $total_students ?> học viên
                                        </div>
                                        <div>
                                            <?php if ($schedule_id): ?>
                                                <a href="/WebEnglishCenter/views/admin/schedules/list_schedules.php"
                                                    class="btn btn-secondary">
                                                    <i class="fas fa-arrow-left"></i> Quay lại lịch học
                                                </a>
                                            <?php else: ?>
                                                <a href="/WebEnglishCenter/views/admin/courses/list_courses.php"
                                                    class="btn btn-secondary">
                                                    <i class="fas fa-arrow-left"></i> Quay lại khóa học
                                                </a>
                                            <?php endif; ?>
                                            <a href="/WebEnglishCenter/views/admin/courses/course_detail.php?id=<?= $course_id ?>"
                                                class="btn btn-primary ms-2">
                                                <i class="fas fa-book"></i> Chi tiết khóa học
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--end::Container-->
            </div>
            <!--end::App Content-->
        </main>
        <!--end::App Main-->

        <!--begin::Footer-->
        <footer class="app-footer">
            <div class="float-end d-none d-sm-inline">Base English Center</div>
            <strong>Copyright &copy; 2024 <a href="#" class="text-decoration-none">Base English Center</a>.</strong> All
            rights reserved.
        </footer>
        <!--end::Footer-->
    </div>
    <!--end::App Wrapper-->

    <!--begin::Script-->
    <!--begin::Third Party Plugin(OverlayScrollbars)-->
    <script src="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/browser/overlayscrollbars.browser.es6.min.js"
        crossorigin="anonymous"></script>
    <!--end::Third Party Plugin(OverlayScrollbars)-->

    <!--begin::Required Plugin(popperjs for Bootstrap 5)-->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
        crossorigin="anonymous"></script>
    <!--end::Required Plugin(popperjs for Bootstrap 5)-->

    <!--begin::Required Plugin(Bootstrap 5)-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.min.js"
        crossorigin="anonymous"></script>
    <!--end::Required Plugin(Bootstrap 5)-->

    <!--begin::Required Plugin(AdminLTE)-->
    <script src="./js/adminlte.js"></script>
    <!--end::Required Plugin(AdminLTE)-->
</body>

</html>
<?php
$stmt2->close();
$conn->close();
?>