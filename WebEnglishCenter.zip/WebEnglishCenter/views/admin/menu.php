<?php
// Kiểm tra session - đảm bảo session_start() đã được gọi ở file cha
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

// Lấy thông tin user từ session
$user_name = $_SESSION['user_name'] ?? 'Alexander Pierce';
$user_avatar = $_SESSION['user_avatar'] ?? 'images/user2-160x160.jpg';
?>

<!--begin::Header-->
<nav class="app-header navbar navbar-expand bg-body">
    <!--begin::Container-->
    <div class="container-fluid">
        <!--begin::Start Navbar Links-->
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" data-lte-toggle="sidebar" href="#" role="button">
                    <i class="bi bi-list"></i>
                </a>
            </li>
            <li class="nav-item d-none d-md-block">
                <a href="/WebEnglishCenter/views/admin/index2.php" class="nav-link">Home</a>
            </li>
            <li class="nav-item d-none d-md-block">
                <a href="/WebEnglishCenter/views/admin/contact.php" class="nav-link">Contact</a>
            </li>
        </ul>
        <!--end::Start Navbar Links-->

        <!--begin::End Navbar Links-->
        <ul class="navbar-nav ms-auto">
            <!--begin::Navbar Search-->
            <li class="nav-item">
                <a class="nav-link" data-widget="navbar-search" href="#" role="button">
                    <i class="bi bi-search"></i>
                </a>
                <!-- Search Form -->
                <div class="navbar-search-block" style="display: none;">
                    <form class="form-inline">
                        <div class="input-group">
                            <input class="form-control" type="search" placeholder="Search" aria-label="Search">
                            <div class="input-group-append">
                                <button class="btn btn-navbar" type="submit">
                                    <i class="bi bi-search"></i>
                                </button>
                                <button class="btn btn-navbar" type="button" data-widget="navbar-search">
                                    <i class="bi bi-x"></i>
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </li>
            <!--end::Navbar Search-->

            <!--begin::Messages Dropdown Menu-->
            <li class="nav-item dropdown">
                <a class="nav-link" data-bs-toggle="dropdown" href="#">
                    <i class="bi bi-chat-text"></i>
                    <span class="navbar-badge badge text-bg-danger">3</span>
                </a>
                <div class="dropdown-menu dropdown-menu-lg dropdown-menu-end">
                    <a href="#" class="dropdown-item">
                        <div class="d-flex">
                            <div class="flex-shrink-0">
                                <img src="images/user1-128x128.jpg" alt="User Avatar"
                                    class="img-size-50 rounded-circle me-3" />
                            </div>
                            <div class="flex-grow-1">
                                <h3 class="dropdown-item-title">
                                    Brad Diesel
                                    <span class="float-end fs-7 text-danger"><i class="bi bi-star-fill"></i></span>
                                </h3>
                                <p class="fs-7">Call me whenever you can...</p>
                                <p class="fs-7 text-secondary">
                                    <i class="bi bi-clock-fill me-1"></i> 4 Hours Ago
                                </p>
                            </div>
                        </div>
                    </a>
                    <div class="dropdown-divider"></div>
                    <a href="#" class="dropdown-item dropdown-footer">See All Messages</a>
                </div>
            </li>
            <!--end::Messages Dropdown Menu-->

            <!--begin::Notifications Dropdown Menu-->
            <li class="nav-item dropdown">
                <a class="nav-link" data-bs-toggle="dropdown" href="#">
                    <i class="bi bi-bell-fill"></i>
                    <span class="navbar-badge badge text-bg-warning">15</span>
                </a>
                <div class="dropdown-menu dropdown-menu-lg dropdown-menu-end">
                    <span class="dropdown-item dropdown-header">15 Notifications</span>
                    <div class="dropdown-divider"></div>
                    <a href="#" class="dropdown-item">
                        <i class="bi bi-envelope me-2"></i> 4 new messages
                        <span class="float-end text-secondary fs-7">3 mins</span>
                    </a>
                    <a href="#" class="dropdown-item dropdown-footer">See All Notifications</a>
                </div>
            </li>
            <!--end::Notifications Dropdown Menu-->

            <!--begin::Fullscreen Toggle-->
            <li class="nav-item">
                <a class="nav-link" href="#" data-lte-toggle="fullscreen">
                    <i data-lte-icon="maximize" class="bi bi-arrows-fullscreen"></i>
                    <i data-lte-icon="minimize" class="bi bi-fullscreen-exit" style="display: none"></i>
                </a>
            </li>
            <!--end::Fullscreen Toggle-->

            <!--begin::User Menu Dropdown-->
            <li class="nav-item dropdown user-menu">
                <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                    <img src="<?php echo $user_avatar; ?>" class="user-image rounded-circle shadow" alt="User Image" />
                    <span class="d-none d-md-inline"><?php echo htmlspecialchars($user_name); ?></span>
                </a>
                <ul class="dropdown-menu dropdown-menu-lg dropdown-menu-end">
                    <li class="user-header text-bg-primary">
                        <img src="<?php echo $user_avatar; ?>" class="rounded-circle shadow" alt="User Image" />
                        <p>
                            <?php echo htmlspecialchars($user_name); ?> - Administrator
                            <small>Member since <?php echo date('M. Y'); ?></small>
                        </p>
                    </li>
                    <li class="user-body">
                        <div class="row">
                            <div class="col-4 text-center">
                                <a href="#">Followers</a>
                            </div>
                            <div class="col-4 text-center">
                                <a href="#">Sales</a>
                            </div>
                            <div class="col-4 text-center">
                                <a href="#">Friends</a>
                            </div>
                        </div>
                    </li>
                    <li class="user-footer">
                        <a href="/WebEnglishCenter/views/admin/profile.php" class="btn btn-default btn-flat">Profile</a>
                        <a href="/WebEnglishCenter/handle/logout_process.php" class="btn btn-default btn-flat float-end"
                            onclick="return confirm('Are you sure you want to logout?')">Sign out</a>
                    </li>
                </ul>
            </li>
            <!--end::User Menu Dropdown-->
        </ul>
        <!--end::End Navbar Links-->
    </div>
    <!--end::Container-->
</nav>
<!--end::Header-->

<!--begin::Sidebar-->
<aside class="app-sidebar bg-body-secondary shadow" data-bs-theme="dark">
    <!--begin::Sidebar Brand-->
    <div class="sidebar-brand">
        <a href="/WebEnglishCenter/views/admin/index2.php" class="brand-link">
            <img src="images/AdminLTELogo.png" alt="AdminLTE Logo" class="brand-image opacity-75 shadow" />
            <span class="brand-text fw-light">English Center</span>
        </a>
    </div>
    <!--end::Sidebar Brand-->

    <!--begin::Sidebar Wrapper-->
    <div class="sidebar-wrapper">
        <nav class="mt-2">
            <!--begin::Sidebar Menu-->
            <ul class="nav sidebar-menu flex-column" data-lte-toggle="treeview" role="navigation"
                aria-label="Main navigation" data-accordion="false" id="navigation">

                <li class="nav-item">
                    <a href="/WebEnglishCenter/views/admin/index2.php"
                        class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'index2.php' ? 'active' : ''; ?>">
                        <i class="nav-icon bi bi-speedometer"></i>
                        <p>Dashboard</p>
                    </a>
                </li>

                <li class="nav-item">
                    <a href="/WebEnglishCenter/views/admin/students/list_students.php"
                        class="nav-link <?php echo str_contains($_SERVER['PHP_SELF'], 'students') ? 'active' : ''; ?>">
                        <i class="nav-icon bi bi-people-fill"></i>
                        <p>Học Viên</p>
                    </a>
                </li>

                <li class="nav-item">
                    <a href="/WebEnglishCenter/views/admin/teachers/list_teachers.php"
                        class="nav-link <?php echo str_contains($_SERVER['PHP_SELF'], 'teachers') ? 'active' : ''; ?>">
                        <i class="nav-icon bi bi-person-badge-fill"></i>
                        <p>Giảng viên</p>
                    </a>
                </li>

                <li class="nav-item">
                    <a href="/WebEnglishCenter/views/admin/courses/list_courses.php"
                        class="nav-link <?php echo str_contains($_SERVER['PHP_SELF'], 'courses') ? 'active' : ''; ?>">
                        <i class="nav-icon bi bi-journal-bookmark-fill"></i>
                        <p>Khóa học</p>
                    </a>
                </li>

                <li class="nav-item">
                    <a href="/WebEnglishCenter/views/admin/classes/list_classes.php"
                        class="nav-link <?php echo str_contains($_SERVER['PHP_SELF'], 'classes') ? 'active' : ''; ?>">
                        <i class="nav-icon bi bi-house-door-fill"></i>
                        <p>Lớp học</p>
                    </a>
                </li>

                <li class="nav-item">
                    <a href="/WebEnglishCenter/views/admin/schedules/list_schedules.php"
                        class="nav-link <?php echo str_contains($_SERVER['PHP_SELF'], 'schedules') ? 'active' : ''; ?>">
                        <i class="nav-icon bi bi-calendar-week-fill"></i>
                        <p>Lịch học</p>
                    </a>
                </li>

                <li class="nav-item">
                    <a href="/WebEnglishCenter/views/admin/enrollments/list_enrollments.php"
                        class="nav-link <?php echo str_contains($_SERVER['PHP_SELF'], 'enrollments') ? 'active' : ''; ?>">
                        <i class="nav-icon bi bi-clipboard-check-fill"></i>
                        <p>Đăng ký khóa học</p>
                    </a>
                </li>

                <li class="nav-item">
                    <a href="/WebEnglishCenter/views/admin/grades/list_grades.php"
                        class="nav-link <?php echo str_contains($_SERVER['PHP_SELF'], 'grades') ? 'active' : ''; ?>">
                        <i class="nav-icon bi bi-bar-chart-fill"></i>
                        <p>Điểm số</p>
                    </a>
                </li>

                <!-- Thêm mục menu mới cho quản lý tài khoản -->


            </ul>
            <!--end::Sidebar Menu-->
        </nav>
    </div>
    <!--end::Sidebar Wrapper-->
</aside>
<!--end::Sidebar-->