<?php
session_start();
include $_SERVER['DOCUMENT_ROOT'] . '/WebEnglishCenter/functions/db_connection.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

$conn = getDbConnection();

// Thống kê cơ bản
$student_count = $conn->query("SELECT COUNT(*) as total FROM students")->fetch_assoc()['total'];
$teacher_count = $conn->query("SELECT COUNT(*) as total FROM teachers")->fetch_assoc()['total'];
$course_count = $conn->query("SELECT COUNT(*) as total FROM courses")->fetch_assoc()['total'];
$schedule_count = $conn->query("SELECT COUNT(*) as total FROM schedules")->fetch_assoc()['total'];
$enrollment_count = $conn->query("SELECT COUNT(*) as total FROM enrollments")->fetch_assoc()['total'];

// Thống kê nâng cao
$active_courses = $conn->query("SELECT COUNT(*) as total FROM courses WHERE id IN (SELECT DISTINCT course_id FROM enrollments)")->fetch_assoc()['total'];
$revenue_month = $conn->query("SELECT COALESCE(SUM(c.fee), 0) as total FROM courses c JOIN enrollments e ON c.id = e.course_id WHERE MONTH(e.enrollment_date) = MONTH(NOW()) AND YEAR(e.enrollment_date) = YEAR(NOW())")->fetch_assoc()['total'];

// Top khóa học phổ biến
$popular_courses = $conn->query("SELECT c.course_name, COUNT(e.id) as enrollments FROM courses c LEFT JOIN enrollments e ON c.id = e.course_id GROUP BY c.id ORDER BY enrollments DESC LIMIT 5");

// Hoạt động gần đây
$recent_enrollments = $conn->query("SELECT s.full_name, c.course_name, e.enrollment_date FROM enrollments e JOIN students s ON e.student_id = s.id JOIN courses c ON e.course_id = c.id ORDER BY e.enrollment_date DESC LIMIT 5");

// Lịch học hôm nay
$today_schedules = $conn->query("SELECT s.start_time, s.end_time, c.course_name, u.full_name as teacher_name 
    FROM schedules s 
    JOIN courses c ON s.course_id = c.id 
    JOIN teachers t ON c.teacher_id = t.id 
    JOIN users u ON t.user_id = u.id  
    WHERE s.schedule_date = CURDATE() 
    ORDER BY s.start_time");

// Thống kê doanh thu theo tháng cho biểu đồ
$revenue_stats = $conn->query("
    SELECT 
        MONTH(e.enrollment_date) as month,
        YEAR(e.enrollment_date) as year,
        COALESCE(SUM(c.fee), 0) as revenue
    FROM enrollments e 
    JOIN courses c ON e.course_id = c.id 
    WHERE e.enrollment_date >= DATE_SUB(NOW(), INTERVAL 6 MONTH)
    GROUP BY YEAR(e.enrollment_date), MONTH(e.enrollment_date)
    ORDER BY year, month
");

$monthly_revenue = [];
$monthly_labels = [];
while ($row = $revenue_stats->fetch_assoc()) {
    $monthly_revenue[] = $row['revenue'];
    $monthly_labels[] = date('M Y', mktime(0, 0, 0, $row['month'], 1, $row['year']));
}

// Thống kê số lượng đăng ký theo khóa học cho biểu đồ tròn
$course_enrollments = $conn->query("
    SELECT c.course_name, COUNT(e.id) as enroll_count
    FROM courses c 
    LEFT JOIN enrollments e ON c.id = e.course_id 
    GROUP BY c.id 
    ORDER BY enroll_count DESC 
    LIMIT 6
");

$course_names = [];
$enroll_counts = [];
while ($row = $course_enrollments->fetch_assoc()) {
    $course_names[] = $row['course_name'];
    $enroll_counts[] = $row['enroll_count'];
}
?>
<!doctype html>
<html lang="en">
<!--begin::Head-->

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Dashboard - Base English Center</title>

    <!--begin::Accessibility Meta Tags-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes" />
    <meta name="color-scheme" content="light dark" />
    <meta name="theme-color" content="#007bff" media="(prefers-color-scheme: light)" />
    <meta name="theme-color" content="#1a1a1a" media="(prefers-color-scheme: dark)" />
    <!--end::Accessibility Meta Tags-->

    <!--begin::Primary Meta Tags-->
    <meta name="title" content="Base English Center - Dashboard" />
    <meta name="author" content="Base English Center" />
    <meta name="description" content="Base English Center Admin Dashboard" />
    <meta name="keywords" content="english center, education, admin dashboard" />
    <!--end::Primary Meta Tags-->

    <!--begin::Accessibility Features-->
    <meta name="supported-color-schemes" content="light dark" />
    <base href="/WebEnglishCenter/">
    <link rel="preload" href="css/admincss/adminlte.css" as="style" />
    <!--end::Accessibility Features-->

    <!--begin::Fonts-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css"
        integrity="sha256-tXJfXfp6Ewt1ilPzLDtQnJV4hclT9XuaZUKyUvmyr+Q=" crossorigin="anonymous" media="print"
        onload="this.media='all'" />
    <!--end::Fonts-->

    <!--begin::Third Party Plugin(OverlayScrollbars)-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css"
        crossorigin="anonymous" />
    <!--end::Third Party Plugin(OverlayScrollbars)-->

    <!--begin::Third Party Plugin(Bootstrap Icons)-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css"
        crossorigin="anonymous" />
    <!--end::Third Party Plugin(Bootstrap Icons)-->

    <!--begin::Required Plugin(AdminLTE)-->
    <link rel="stylesheet" href="css/admincss/adminlte.css" />
    <!--end::Required Plugin(AdminLTE)-->

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />

    <!-- apexcharts -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/apexcharts@3.37.1/dist/apexcharts.css"
        integrity="sha256-4MX+61mt9NVvvuPjUWdUdyfZfxSB1/Rf9WtqRHgG5S0=" crossorigin="anonymous" />
</head>

<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
    <!--begin::App Wrapper-->
    <div class="app-wrapper">

        <!-- Include Menu -->
        <?php include 'menu.php'; ?>

        <!--begin::App Main-->
        <main class="app-main">
            <!--begin::App Content Header-->
            <div class="app-content-header">
                <!--begin::Container-->
                <div class="container-fluid">
                    <!--begin::Row-->
                    <div class="row">
                        <div class="col-sm-6">
                            <h3 class="mb-0">Dashboard</h3>
                        </div>
                        <div class="col-sm-6">
                            <ol class="breadcrumb float-sm-end">
                                <li class="breadcrumb-item"><a href="views/admin/index2.php">Home</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Dashboard</li>
                            </ol>
                        </div>
                    </div>
                    <!--end::Row-->
                </div>
                <!--end::Container-->
            </div>

            <div class="app-content">
                <!--begin::Container-->
                <div class="container-fluid">
                    <!-- Info boxes -->
                    <div class="row">
                        <div class="col-12 col-sm-6 col-md-3">
                            <div class="info-box">
                                <span class="info-box-icon text-bg-primary shadow-sm">
                                    <i class="fas fa-user-graduate"></i>
                                </span>
                                <div class="info-box-content">
                                    <span class="info-box-text">Học viên</span>
                                    <span class="info-box-number"><?= number_format($student_count) ?></span>
                                </div>
                            </div>
                        </div>
                        <!-- /.col -->
                        <div class="col-12 col-sm-6 col-md-3">
                            <div class="info-box">
                                <span class="info-box-icon text-bg-success shadow-sm">
                                    <i class="fas fa-chalkboard-teacher"></i>
                                </span>
                                <div class="info-box-content">
                                    <span class="info-box-text">Giảng viên</span>
                                    <span class="info-box-number"><?= number_format($teacher_count) ?></span>
                                </div>
                            </div>
                        </div>
                        <!-- /.col -->
                        <div class="col-12 col-sm-6 col-md-3">
                            <div class="info-box">
                                <span class="info-box-icon text-bg-info shadow-sm">
                                    <i class="fas fa-book"></i>
                                </span>
                                <div class="info-box-content">
                                    <span class="info-box-text">Khóa học</span>
                                    <span class="info-box-number"><?= number_format($course_count) ?></span>
                                </div>
                            </div>
                        </div>
                        <!-- /.col -->
                        <div class="col-12 col-sm-6 col-md-3">
                            <div class="info-box">
                                <span class="info-box-icon text-bg-warning shadow-sm">
                                    <i class="fas fa-money-bill-wave"></i>
                                </span>
                                <div class="info-box-content">
                                    <span class="info-box-text">Doanh thu tháng</span>
                                    <span class="info-box-number"><?= number_format($revenue_month) ?> VNĐ</span>
                                </div>
                            </div>
                        </div>
                        <!-- /.col -->
                    </div>
                    <!-- /.row -->

                    <!--begin::Row-->
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card mb-4">
                                <div class="card-header">
                                    <h5 class="card-title">Báo cáo doanh thu</h5>
                                    <div class="card-tools">
                                        <button type="button" class="btn btn-tool" data-lte-toggle="card-collapse">
                                            <i data-lte-icon="expand" class="bi bi-plus-lg"></i>
                                            <i data-lte-icon="collapse" class="bi bi-dash-lg"></i>
                                        </button>
                                        <button type="button" class="btn btn-tool" data-lte-toggle="card-remove">
                                            <i class="bi bi-x-lg"></i>
                                        </button>
                                    </div>
                                </div>
                                <!-- /.card-header -->
                                <div class="card-body">
                                    <!--begin::Row-->
                                    <div class="row">
                                        <div class="col-md-8">
                                            <p class="text-center">
                                                <strong>Doanh thu 6 tháng gần đây</strong>
                                            </p>
                                            <div id="revenue-chart"></div>
                                        </div>
                                        <!-- /.col -->
                                        <div class="col-md-4">
                                            <p class="text-center">
                                                <strong>Thống kê tổng quan</strong>
                                            </p>
                                            <div class="progress-group">
                                                Tỷ lệ lấp đầy khóa học
                                                <span
                                                    class="float-end"><b><?= $active_courses ?></b>/<?= $course_count ?></span>
                                                <div class="progress progress-sm">
                                                    <div class="progress-bar text-bg-primary"
                                                        style="width: <?= $course_count > 0 ? ($active_courses / $course_count * 100) : 0 ?>%">
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- /.progress-group -->
                                            <div class="progress-group">
                                                Tổng đăng ký
                                                <span
                                                    class="float-end"><b><?= number_format($enrollment_count) ?></b></span>
                                                <div class="progress progress-sm">
                                                    <div class="progress-bar text-bg-success" style="width: 100%"></div>
                                                </div>
                                            </div>
                                            <!-- /.progress-group -->
                                            <div class="progress-group">
                                                Lịch học tháng này
                                                <span
                                                    class="float-end"><b><?= number_format($schedule_count) ?></b></span>
                                                <div class="progress progress-sm">
                                                    <div class="progress-bar text-bg-info" style="width: 100%"></div>
                                                </div>
                                            </div>
                                            <!-- /.progress-group -->
                                        </div>
                                        <!-- /.col -->
                                    </div>
                                    <!--end::Row-->
                                </div>
                                <!-- ./card-body -->
                            </div>
                            <!-- /.card -->
                        </div>
                        <!-- /.col -->
                    </div>
                    <!--end::Row-->

                    <!--begin::Row-->
                    <div class="row">
                        <!-- Start col -->
                        <div class="col-md-8">
                            <!-- Hoạt động gần đây -->
                            <div class="card mb-4">
                                <div class="card-header">
                                    <h3 class="card-title">Hoạt động gần đây</h3>
                                    <div class="card-tools">
                                        <button type="button" class="btn btn-tool" data-lte-toggle="card-collapse">
                                            <i data-lte-icon="expand" class="bi bi-plus-lg"></i>
                                            <i data-lte-icon="collapse" class="bi bi-dash-lg"></i>
                                        </button>
                                    </div>
                                </div>
                                <!-- /.card-header -->
                                <div class="card-body p-0">
                                    <div class="table-responsive">
                                        <table class="table m-0">
                                            <thead>
                                                <tr>
                                                    <th>Học viên</th>
                                                    <th>Khóa học</th>
                                                    <th>Thời gian</th>
                                                    <th>Trạng thái</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php if ($recent_enrollments->num_rows > 0): ?>
                                                    <?php while ($enrollment = $recent_enrollments->fetch_assoc()): ?>
                                                        <tr>
                                                            <td><?= htmlspecialchars($enrollment['full_name']) ?></td>
                                                            <td><?= htmlspecialchars($enrollment['course_name']) ?></td>
                                                            <td><?= date('d/m/Y H:i', strtotime($enrollment['enrollment_date'])) ?>
                                                            </td>
                                                            <td><span class="badge text-bg-success">Đã đăng ký</span></td>
                                                        </tr>
                                                    <?php endwhile; ?>
                                                <?php else: ?>
                                                    <tr>
                                                        <td colspan="4" class="text-center">Không có hoạt động gần đây</td>
                                                    </tr>
                                                <?php endif; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    <!-- /.table-responsive -->
                                </div>
                                <!-- /.card-body -->
                            </div>
                            <!-- /.card -->

                            <!-- Lịch học hôm nay -->
                            <div class="card">
                                <div class="card-header">
                                    <h3 class="card-title">Lịch học hôm nay</h3>
                                    <div class="card-tools">
                                        <button type="button" class="btn btn-tool" data-lte-toggle="card-collapse">
                                            <i data-lte-icon="expand" class="bi bi-plus-lg"></i>
                                            <i data-lte-icon="collapse" class="bi bi-dash-lg"></i>
                                        </button>
                                    </div>
                                </div>
                                <!-- /.card-header -->
                                <div class="card-body p-0">
                                    <div class="table-responsive">
                                        <table class="table m-0">
                                            <thead>
                                                <tr>
                                                    <th>Thời gian</th>
                                                    <th>Khóa học</th>
                                                    <th>Giảng viên</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php if ($today_schedules->num_rows > 0): ?>
                                                    <?php while ($schedule = $today_schedules->fetch_assoc()): ?>
                                                        <tr>
                                                            <td><?= date('H:i', strtotime($schedule['start_time'])) ?> -
                                                                <?= date('H:i', strtotime($schedule['end_time'])) ?>
                                                            </td>
                                                            <td><?= htmlspecialchars($schedule['course_name']) ?></td>
                                                            <td><?= htmlspecialchars($schedule['teacher_name']) ?></td>
                                                        </tr>
                                                    <?php endwhile; ?>
                                                <?php else: ?>
                                                    <tr>
                                                        <td colspan="3" class="text-center">Không có lịch học hôm nay</td>
                                                    </tr>
                                                <?php endif; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    <!-- /.table-responsive -->
                                </div>
                                <!-- /.card-body -->
                            </div>
                            <!-- /.card -->
                        </div>
                        <!-- /.col -->

                        <div class="col-md-4">
                            <!-- Khóa học phổ biến -->
                            <div class="card mb-4">
                                <div class="card-header">
                                    <h3 class="card-title">Khóa học phổ biến</h3>
                                    <div class="card-tools">
                                        <button type="button" class="btn btn-tool" data-lte-toggle="card-collapse">
                                            <i data-lte-icon="expand" class="bi bi-plus-lg"></i>
                                            <i data-lte-icon="collapse" class="bi bi-dash-lg"></i>
                                        </button>
                                    </div>
                                </div>
                                <!-- /.card-header -->
                                <div class="card-body">
                                    <div id="courses-chart"></div>
                                </div>
                                <!-- /.card-body -->
                            </div>
                            <!-- /.card -->

                            <!-- Thống kê nhanh -->
                            <div class="card">
                                <div class="card-header">
                                    <h3 class="card-title">Thống kê nhanh</h3>
                                </div>
                                <!-- /.card-header -->
                                <div class="card-body p-0">
                                    <ul class="nav nav-pills flex-column">
                                        <li class="nav-item">
                                            <a href="#" class="nav-link">
                                                Khóa học đang hoạt động
                                                <span class="float-end text-primary">
                                                    <?= $active_courses ?>
                                                </span>
                                            </a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="#" class="nav-link">
                                                Tổng đăng ký
                                                <span class="float-end text-success">
                                                    <?= number_format($enrollment_count) ?>
                                                </span>
                                            </a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="#" class="nav-link">
                                                Lịch học
                                                <span class="float-end text-info">
                                                    <?= number_format($schedule_count) ?>
                                                </span>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                                <!-- /.footer -->
                            </div>
                            <!-- /.card -->
                        </div>
                        <!-- /.col -->
                    </div>
                    <!--end::Row-->
                </div>
                <!--end::Container-->
            </div>
            <!--end::App Content-->
        </main>
        <!--end::App Main-->

        <!--begin::Footer-->
        <footer class="app-footer">
            <div class="float-end d-none d-sm-inline">Base English Center</div>
            <strong>Copyright &copy; 2024 <a href="#" class="text-decoration-none">Base English Center</a>.</strong> All
            rights reserved.
        </footer>
        <!--end::Footer-->
    </div>
    <!--end::App Wrapper-->

    <!--begin::Script-->
    <!--begin::Third Party Plugin(OverlayScrollbars)-->
    <script src="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/browser/overlayscrollbars.browser.es6.min.js"
        crossorigin="anonymous"></script>
    <!--end::Third Party Plugin(OverlayScrollbars)-->

    <!--begin::Required Plugin(popperjs for Bootstrap 5)-->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
        crossorigin="anonymous"></script>
    <!--end::Required Plugin(popperjs for Bootstrap 5)-->

    <!--begin::Required Plugin(Bootstrap 5)-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.min.js"
        crossorigin="anonymous"></script>
    <!--end::Required Plugin(Bootstrap 5)-->

    <!--begin::Required Plugin(AdminLTE)-->
    <script src="js/adminlte.js"></script>
    <!--end::Required Plugin(AdminLTE)-->

    <!-- apexcharts -->
    <script src="https://cdn.jsdelivr.net/npm/apexcharts@3.37.1/dist/apexcharts.min.js"
        integrity="sha256-+vh8GkaU7C9/wbSLIcwq82tQ2wTf44aOHA8HlBMwRI8=" crossorigin="anonymous"></script>

    <script>
        // Biểu đồ doanh thu
        const revenue_chart_options = {
            series: [{
                name: 'Doanh thu',
                data: <?= json_encode($monthly_revenue) ?>
            }],
            chart: {
                height: 350,
                type: 'area',
                toolbar: {
                    show: false,
                },
            },
            colors: ['#0d6efd'],
            dataLabels: {
                enabled: false
            },
            stroke: {
                curve: 'smooth'
            },
            xaxis: {
                categories: <?= json_encode($monthly_labels) ?>
            },
            tooltip: {
                x: {
                    format: 'MMM yyyy'
                },
            },
        };

        const revenue_chart = new ApexCharts(
            document.querySelector('#revenue-chart'),
            revenue_chart_options
        );
        revenue_chart.render();

        // Biểu đồ khóa học phổ biến
        const courses_chart_options = {
            series: <?= json_encode($enroll_counts) ?>,
            chart: {
                type: 'donut',
                height: 350 // Thêm chiều cao
            },
            labels: <?= json_encode($course_names) ?>,
            dataLabels: {
                enabled: false,
            },
            colors: ['#0d6efd', '#20c997', '#ffc107', '#d63384', '#6f42c1', '#fd7e14'],
            legend: {
                position: 'bottom'
            }
        };

        const courses_chart = new ApexCharts(document.querySelector('#courses-chart'), courses_chart_options);
        courses_chart.render();

        // OverlayScrollbars Configure
        const SELECTOR_SIDEBAR_WRAPPER = '.sidebar-wrapper';
        const Default = {
            scrollbarTheme: 'os-theme-light',
            scrollbarAutoHide: 'leave',
            scrollbarClickScroll: true,
        };

        document.addEventListener('DOMContentLoaded', function () {
            const sidebarWrapper = document.querySelector(SELECTOR_SIDEBAR_WRAPPER);
            const isMobile = window.innerWidth <= 992;

            if (sidebarWrapper && OverlayScrollbarsGlobal?.OverlayScrollbars !== undefined && !isMobile) {
                OverlayScrollbarsGlobal.OverlayScrollbars(sidebarWrapper, {
                    scrollbars: {
                        theme: Default.scrollbarTheme,
                        autoHide: Default.scrollbarAutoHide,
                        clickScroll: Default.scrollbarClickScroll,
                    },
                });
            }
        });
    </script>
    <!--end::Script-->
</body>
<!--end::Body-->

</html>