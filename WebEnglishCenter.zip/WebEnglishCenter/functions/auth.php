<?php
/**
 * Khởi tạo session nếu chưa có
 */
function startSession()
{
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
}

/**
 * Kiểm tra user đã đăng nhập chưa
 */
function checkLogin($redirectPath = '../login.php')
{
    startSession();
    if (!isset($_SESSION['user_id'])) {
        $_SESSION['error'] = "Vui lòng đăng nhập!";
        header("Location: " . $redirectPath);
        exit();
    }
}

/**
 * Hàm kiểm tra quyền ADMIN
 */
function checkAdmin($redirectPath = '../client/index_client.php')
{
    startSession();
    if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
        $_SESSION['error'] = "Bạn không có quyền truy cập trang quản trị!";
        header("Location: " . $redirectPath);
        exit();
    }
}

/**
 * Hàm kiểm tra quyền CLIENT (user, student, teacher)
 */
function checkClient($redirectPath = '../admin/index.php')
{
    startSession();
    if (!isset($_SESSION['role']) || $_SESSION['role'] === 'admin') {
        $_SESSION['error'] = "Admin không thể truy cập trang dành cho học viên!";
        header("Location: " . $redirectPath);
        exit();
    }
}

/**
 * Hàm đăng xuất
 */
function logout($redirectPath = '../login.php')
{
    startSession();
    session_unset();
    session_destroy();
    session_start();
    $_SESSION['success'] = "Đăng xuất thành công!";
    header("Location: " . $redirectPath);
    exit();
}

/**
 * Lấy thông tin user hiện tại
 */
function getCurrentUser()
{
    startSession();
    if (isset($_SESSION['user_id'])) {
        return [
            'id' => $_SESSION['user_id'],
            'username' => $_SESSION['username'],
            'role' => $_SESSION['role']
        ];
    }
    return null;
}

/**
 * Kiểm tra có đăng nhập hay không
 */
function isLoggedIn()
{
    startSession();
    return isset($_SESSION['user_id']);
}

/**
 * Xác thực đăng nhập
 * (Khuyên dùng password_verify nếu mật khẩu đã mã hóa)
 */
function authenticateUser($conn, $username, $password)
{
    $sql = "SELECT id, username, password, role FROM users WHERE username = ? LIMIT 1";
    $stmt = mysqli_prepare($conn, $sql);

    if (!$stmt)
        return false;

    mysqli_stmt_bind_param($stmt, "s", $username);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if ($result && mysqli_num_rows($result) > 0) {
        $user = mysqli_fetch_assoc($result);

        // Kiểm tra password (nếu có mã hóa thì dùng password_verify)
        if ($password === $user['password']) {
            return $user;
        }
    }

    return false;
}
?>