<?php
session_start();

// include file kết nối
include '../functions/db_connection.php';

// Tạo kết nối
$conn = getDbConnection();

if (isset($_POST['username']) && isset($_POST['password'])) {
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    // Sử dụng prepared statement để chống SQL injection
    $sql = "SELECT * FROM users WHERE username = ? LIMIT 1";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $user = $result->fetch_assoc();

        // Kiểm tra password (sau này nên dùng password_verify nếu dùng password_hash)
        if ($user['password'] === $password) {
            // Lưu session
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['role'] = $user['role'];
            $_SESSION['logged_in'] = true;

            // PHÂN QUYỀN THEO ROLE
            if ($user['role'] === 'admin') {
                header("Location: ../views/admin/index2.php");
                exit();
            } else {
                header("Location: ../index_client.php");
                exit();
            }
        } else {
            $_SESSION['error'] = "Sai username hoặc password!";
            header("Location: ../login.php");
            exit();
        }
    } else {
        $_SESSION['error'] = "Sai username hoặc password!";
        header("Location: ../login.php");
        exit();
    }

} else {
    $_SESSION['error'] = "Vui lòng nhập đầy đủ thông tin!";
    header("Location: ../login.php");
    exit();
}

$conn->close();
?>